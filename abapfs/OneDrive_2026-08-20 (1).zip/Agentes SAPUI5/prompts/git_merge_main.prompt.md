---
name: git-merge-main
description: 'Fusiona de forma segura la rama actual hacia main remota evitando force push, rebase automático y pérdida de cambios.'
agent: agent
tools: ['execute']
argument-hint: '[remoto opcional, por defecto origin]'
---

# Prompt: SAPUI5 – Merge de la rama actual hacia main (remota) de forma segura

Eres un asistente dentro de VSCode en un proyecto SAPUI5.
Objetivo: tomar los cambios de la rama actual y fusionarlos en la rama `main` y publicarlos en el remoto (por defecto `origin/main`).

Requisitos:
- NO usar `push --force` ni reescrituras de historial.
- Trabajar con `origin` si existe.
- Sincronizar con remoto antes de mergear (fetch y fast-forward de main si es posible).
- Si hay conflictos durante el merge, abortar el merge y volver al estado estable.
- Mostrar mensajes claros de éxito o fallo (con pasos sugeridos).
- NO hacer rebase automático de la rama actual.
- Mantener cambios locales del usuario a salvo (stash solo si es necesario y avisando).

## Pasos (estrictos)

1) Verifica que estás en un repo Git:
- `git rev-parse --is-inside-work-tree`
- Si falla: “No estoy en un repositorio Git. Aborto.”

2) Detecta rama actual:
- `git branch --show-current`
- Si la rama actual está vacía: aborta con mensaje.
- Si la rama actual es `main`: muestra “Ya estás en main. No hay nada que mergear desde otra rama.” y termina.

3) Verifica remoto:
- `git remote`
- Usa `origin` si existe.
- Si no existe `origin`: pide al usuario indicar el remoto, o aborta con “No existe remoto origin.”

4) Asegura que no hay cambios sin commit en working tree:
- `git status --porcelain`
- Si hay cambios:
  - Muestra: “Tienes cambios locales sin commit. Para evitar mezclar, haré stash temporal.”
  - Ejecuta: `git stash push -u -m "autostash-before-merge-to-main"`
  - Nota: al final, intenta `git stash pop` si todo fue bien; si hubo conflicto, NO hagas pop automático.

5) Actualiza referencias remotas:
- `git fetch --prune <REMOTE>`

6) Asegura que `main` existe localmente:
- Comprueba: `git show-ref --verify --quiet refs/heads/main`
- Si NO existe:
  - Crea tracking: `git checkout -b main --track <REMOTE>/main`
- Si existe:
  - `git checkout main`

7) Sincroniza `main` local con `main` remota (sin rebase):
- Intenta fast-forward:
  - `git merge --ff-only <REMOTE>/main`
- Si falla (por divergencia):
  - Muestra: “Tu main local diverge del remoto. No haré merge automático. Revisa tu historial y resuelve manualmente.”
  - Si se hizo stash en el paso 4, deja el stash intacto.
  - Termina.

8) Mergea la rama de origen (la rama inicial detectada en el paso 2) hacia `main`:
- Ejecuta: `git merge <SOURCE_BRANCH> --no-ff -m "merge: <SOURCE_BRANCH> -> main"`
- Si hay conflictos (merge devuelve error):
  a) Ejecuta: `git merge --abort`
  b) Muestra: “❌ Conflicto al mergear <SOURCE_BRANCH> en main. He abortado el merge y el repositorio vuelve a estado estable. Resuelve conflictos manualmente y reintenta.”
  c) Si había stash: NO hacer pop automático; indica cómo recuperarlo:
     - “Tu stash sigue guardado: `git stash list` / `git stash pop`”
  d) Termina.

9) Publica `main` al remoto:
- Ejecuta: `git push <REMOTE> main`
- Si el push es rechazado (non-fast-forward):
  a) No fuerces.
  b) Muestra: “❌ Push rechazado porque main remota avanzó. Ejecuta `git fetch` y revisa cambios en <REMOTE>/main; luego reintenta el merge.”
  c) Termina.

10) Restauración de stash (si se creó en el paso 4):
- Si todo fue bien y se creó stash:
  - Intenta: `git stash pop`
  - Si hay conflicto al hacer pop:
    - Muestra: “⚠️ El merge/push fue correcto, pero hay conflictos al restaurar tu stash. Revisa `git status` y resuelve.”
  - Si fue bien:
    - Muestra: “Stash restaurado correctamente.”

11) Mensaje final:
- Si todo OK:
  - “✅ Merge realizado: <SOURCE_BRANCH> -> main y publicado en <REMOTE>/main.”

## Reglas de seguridad
- Nunca ejecutar `git push --force` ni `--force-with-lease`.
- No borrar ramas.
- No rebasear la rama de origen automáticamente.
- Mantener cambios del usuario a salvo (stash solo si hay cambios sin commit).
