---
name: generacion-dt
description: 'Genera un documento de diseño técnico SAPUI5 completo a partir del proyecto abierto.'
agent: agent
tools: ['read', 'search', 'edit']
argument-hint: '[ruta destino opcional para el documento Markdown]'
---

# Prompt: Generación de Documento Técnico SAPUI5 (Diseño Técnico)

Actúa como un arquitecto y desarrollador senior de SAPUI5/Fiori. Necesito que generes un documento Markdown (.md) estilo “Diseño Técnico / Technical Design Document” a partir del proyecto SAPUI5 que tengo abierto en este workspace.

Objetivo: este .md debe permitir reconstruir el proyecto en uno nuevo, con el máximo detalle posible.

REGLAS:
- NO inventes nada. Si falta información, marca: “(TODO: no encontrado en el repo)” y sugiere dónde debería estar.
- Siempre que describas algo, indica la ruta del archivo y, si aplica, el nombre exacto de la clase/control/función.
- Si hay configuraciones (manifest, routing, models, i18n), detállalas con exactitud.
- Incluye listas y tablas cuando ayuden.
- Usa secciones claras con encabezados (##, ###).
- Prioriza precisión y exhaustividad por encima de brevedad.

TAREA:
1) Recorre el repositorio y analiza:
   - package.json / ui5.yaml (si existe)
   - webapp/manifest.json
   - webapp/Component.js
   - webapp/controller/**
   - webapp/view/**
   - webapp/model/**
   - webapp/service/** o webapp/util/** (si existen)
   - webapp/i18n/**
   - webapp/css/**, webapp/fragment/**, webapp/test/** (si existen)

2) Genera un único archivo Markdown con el siguiente índice, relleno:

# cursoSAPUI5 — Diseño Técnico (SAPUI5)

## 1. Resumen
- Propósito del proyecto
- Alcance funcional (alto nivel)
- Suposiciones y dependencias externas

## 2. Stack y dependencias
- Versión SAPUI5/OpenUI5 (si se deduce)
- Librerías UI5 usadas (manifest.json -> sap.ui5/dependencies)
- Dependencias npm (package.json)
- Scripts de build/serve/test

## 3. Estructura del repositorio
- Árbol de carpetas relevante (resumen)
- Convenciones de nombres
- Entrypoints

## 4. Configuración UI5
Cuando sea crítico (routing/models/datasources), incluye extractos JSON relevantes (no todo el archivo entero) y referencia el path exacto.

### 4.1 manifest.json (detalle completo)
- sap.app: id, type, applicationVersion, dataSources
- sap.ui: deviceTypes, icons
- sap.ui5:
  - dependencies (libs y minVersion)
  - models (cada modelo con type, uri, settings, bindingMode, preload)
  - resources (css)
  - rootView
  - routing (config + routes + targets)
  - extends / contentDensities
Incluye tablas:
- Tabla de modelos
- Tabla de rutas (pattern, name, target, view, controller)

### 4.2 Component.js
- Inicialización
- Creación de modelos
- Manejo de router
- Cualquier extend/override

### 4.3 index.html / flpSandbox / launch config (si existe)
- Cómo arranca la app
- Parámetros relevantes

## 5. Arquitectura y flujo de navegación
- Mapa de pantallas (views)
- Flujo de navegación (routing)
- Estados relevantes (URL params / query params)

## 6. Vistas y controladores (por pantalla)
Para cada vista:
- Ruta del archivo view (.view.xml o .js)
- Controller asociado y ruta
- Responsabilidades
- Controles principales usados
- Modelos/bindings relevantes
- Eventos UI (onInit, onBeforeRendering, handlers)
- Validaciones
- Formateadores usados
- Fragmentos/diálogos asociados

## 7. Modelos, servicios y acceso a datos
- DataSources del manifest
- OData/REST: endpoints, colecciones, entidades, operaciones usadas
- Mapeo: qué pantallas consumen qué servicios
- Capa de servicio (métodos, firmas, rutas de archivo)
- Gestión de errores y mensajes (MessageBox/MessageToast/MessageManager)

## 8. Reglas de negocio
- Reglas y validaciones (dónde están, cómo funcionan)
- Transformaciones de datos
- Formateadores (archivos y funciones)

## 9. i18n y textos
- Estructura de bundles
- Convención de claves
- Ejemplos de claves críticas

## 10. Estilos y theming
- CSS/LESS/SASS si hay
- Clases usadas por pantalla
- Consideraciones de responsive/content density

## 11. Seguridad y autorizaciones (si aplica)
- Roles/targets/visibilidad en UI (si existe lógica)
- Sanitización/validación de inputs

## 12. Logging, trazas y manejo de errores
- Estrategia de logging
- Puntos críticos
- Errores típicos y mitigación

## 13. Testing
- Unit tests (QUnit), OPA, e2e (si existe)
- Cómo ejecutar
- Cobertura esperada

## 14. Build y despliegue
- Comandos para build
- Artefactos generados
- Deploy target (BTP, ABAP, Launchpad, etc. si se deduce)
- Variables/entornos

## 15. Configuración de ejecución (UI5 Tooling)

Para cada uno de los siguientes archivos, incluye:

- Ruta exacta
- Propósito
- Escenario de uso (local, mock, productivo)
- Configuración completa copiada en bloque de código YAML
- Explicación de middlewares, proxies y mockserver si existen

### 15.1 ui5.yaml
- Tipo de proyecto
- Framework (OpenUI5/SAPUI5)
- Librerías
- Custom tasks
- Custom middlewares

### 15.2 ui5-local.yaml
- Overrides respecto a ui5.yaml
- Proxy configuration
- Backend destino

### 15.3 ui5-mock.yaml
- Configuración de mockserver
- Ruta de metadata
- Ruta de mockdata
- Configuración de simulación (delay, autoRespond, etc.)

IMPORTANTE:
- Copia el contenido completo de cada archivo en bloques de código YAML
- No resumas ni simplifiques
- Si alguno no existe, indícalo explícitamente

## 16. Guía de recreación del proyecto desde cero
- Pasos para crear un proyecto nuevo (yo lo ejecutaré)
- Archivos que hay que reproducir y en qué orden
- Checklist final de verificación

3) Al final añade:
- “Gaps / TODOs” (lo que no encontraste)
- “Riesgos y decisiones técnicas”
- “Mejoras recomendadas”

IMPORTANTE: Antes de escribir el documento final, haz una fase breve de “inventario”:
- Lista de archivos clave encontrados (con rutas)
- Lista de vistas/controladores detectados
- Lista de modelos y rutas

Luego escribe el .md completo.
