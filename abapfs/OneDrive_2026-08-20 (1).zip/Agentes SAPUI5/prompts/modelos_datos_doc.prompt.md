---
name: modelos-datos-doc
description: 'Documenta modelos de datos SAPUI5 globales y por vista en data-models.md.'
agent: agent
tools: ['read', 'search', 'edit']
argument-hint: '[ruta destino opcional]'
---

# Prompt: Documentación de Modelos de Datos en SAPUI5 (Globales + Por Vista)

Actúa como un desarrollador senior SAPUI5/Fiori y como “documentation writer”.
Tu tarea es generar documentación técnica clara y verificable sobre los MODELOS de datos que se usan en este proyecto SAPUI5.

## Objetivo
- Documentar TODOS los modelos usados en el proyecto:
  - Modelos globales (manifest.json, Component.js, App)
  - Modelos por vista y controlador
- Generar una salida final en **Markdown**, escribirse directamente en este archivo `data-models.md`. Si el fichero o la carpeta no existen, indícalo e intentar crearlo.
- Empieza analizando manifest.json y Component.js. Si necesitas más archivos, indícalo antes de continuar.

## Alcance de análisis:
- webapp/manifest.json (sap.ui5/models, dataSources)
- webapp/Component.js (init, setModel, getModel)
- webapp/controller/**/*.controller.js
- webapp/view/**/*.view.xml
- webapp/fragment/**/*.fragment.xml
- webapp/model/*

## Para cada modelo documenta:
- Nombre / alias (o default)
- Tipo (OData V2/V4, JSONModel, ResourceModel, etc.)
- Dónde se define (archivo y método)
- Uso principal
- Paths o entidades más usadas
- Vistas donde se consume

## Estructura obligatoria del documento:
1. Resumen Ejecutivo
2. Inventario de Modelos Globales
3. Inventario de Modelos por Vista
4. Mapa de Bindings relevantes
5. Observaciones y recomendaciones

## Reglas:
- No inventes información
- Si algo no se encuentra, indícalo como "No encontrado"
- Usa ejemplos reales de bindings cuando existan
- Escribe en español técnico
