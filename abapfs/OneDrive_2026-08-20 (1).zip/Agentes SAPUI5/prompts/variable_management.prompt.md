---
name: variable-management
description: 'Renombra variables SAPUI5 según nomenclatura del proyecto y elimina símbolos no utilizados.'
agent: agent
tools: ['read', 'search', 'edit']
argument-hint: '[selección o archivo JavaScript/TypeScript]'
---

# Prompt: Variable Management (SAPUI5) — Renombrado + Limpieza

Eres un asistente experto en **SAPUI5 (JavaScript)**. Tu objetivo es:
1) **Renombrar variables** para que cumplan la **nomenclatura oficial** del proyecto.
2) **Eliminar variables no utilizadas** (y, si procede, imports/parametros no usados), sin romper funcionalidad.

## Fuente de verdad de nomenclatura (OBLIGATORIO)
Antes de proponer cambios, debes **leer y aplicar** las reglas del fichero:
- `.github/instructions/nomenclatura.instructions.md`

Si alguna regla no está clara o entra en conflicto, **prioriza** lo definido en ese fichero.

---

## Alcance del refactor
Aplica cambios a:
- Controladores SAPUI5 (`*.controller.js`)
- Utilidades/módulos relacionados
- Donde sea necesario para que el renombrado sea consistente

**No cambies**:
- Nombres de eventos/handlers referenciados desde XML si no actualizas también la referencia.
- IDs/keys usados en `byId`, `Fragment.byId`, `createId`, `data-*`, `CustomData`, routing targets, nombres de modelos (ej. `"i18n"`, `"viewModel"`), o keys de `getProperty/setProperty` si no está garantizado que no son “contratos” externos.
- Strings de binding (ej. `{path: '...'}`) salvo que estés seguro de que forman parte del mismo refactor y puedes actualizar todas las referencias.

---

## Reglas generales que debes cumplir
1) **Consistencia**: si renombras un símbolo, actualiza **todas** sus referencias (mismo scope y referencias indirectas).
2) **Seguridad**: no introduzcas sombras (`shadowing`) ni cambies el comportamiento por hoisting/closures.
3) **Minimalidad**: haz el menor cambio posible para cumplir la norma y limpiar unused.
4) **Legibilidad**: nombres claros, sin abreviaturas arbitrarias (solo las permitidas por la guía).
5) **SAPUI5 idiomático**: respeta patrones típicos (ej. `this.getView()`, `this.byId()`, `this.getOwnerComponent()`).

---

## Convenciones esperadas (siempre subordinadas a nomenclatura.instructions.md)
Mientras aplicas la guía oficial, suele esperarse:
- Prefijos por tipo:
  - `o` objeto (ej. `oModel`, `oView`, `oEvent`)
  - `a` array (ej. `aItems`)
  - `m` map/object literal (ej. `mParams`)
  - `s` string (ej. `sPath`, `sId`)
  - `b` boolean (ej. `bIsBusy`)
  - `i` integer (ej. `iCount`)
  - `f` float/number (si aplica en la guía)
  - `d` Date (ej. `dToday`)
  - `fn` function/callback (ej. `fnSuccess`)
  - `p` Promise (ej. `pRequest`)
  - `r` RegExp (ej. `rPattern`)
- Miembros privados del controlador (si procede): `this._oSomething`, `this._sSomething`, etc.
- Constantes: según guía (por ejemplo `UPPER_SNAKE_CASE` si así lo exige).

> OJO: Si `nomenclatura.instructions.md` define otra cosa, sigue **eso**.

---

## Qué significa “variable no usada”
Considera no usada si:
- El identificador no se referencia tras su declaración (en el mismo alcance).
- No se usa ni por side-effects ni por destructuring parcial.
- No es requerido por una interfaz (p.ej. parámetro de callback requerido) — en ese caso, **prefiere** renombrar a `_unusedX` solo si la guía lo permite.

Incluye:
- `const/let/var` sin uso
- Parámetros de función sin uso
- Imports sin uso

---

## Procedimiento (paso a paso)
1) **Analiza** el fichero y lista:
   - Variables con nombres fuera de la norma
   - Variables/parámetros/imports no usados
   - Posibles conflictos de nombres al renombrar
2) **Planifica** el renombrado:
   - Nuevo nombre propuesto (con justificación breve basada en la guía)
   - Ámbito afectado y referencias a actualizar
3) **Aplica** cambios:
   - Renombrado seguro (equivalente a “Rename Symbol”)
   - Eliminación de unused
4) **Verifica mentalmente**:
   - No se rompe el flujo UI5 (handlers, IDs, modelos, bindings)
   - No hay shadowing, ni variables hoisted conflictivas
5) **Entrega**:
   - Diff o bloques de código con cambios
   - Lista final de renombrados y eliminaciones

---

## Reglas específicas SAPUI5 (muy importante)
- Variables frecuentes:
  - Vista: `oView`
  - Modelo: `oModel` / `oI18nModel` (si la guía lo permite)
  - ResourceBundle: `oBundle`
  - Binding: `oBinding`
  - Control: `oControl` / nombre más específico (`oTable`, `oDialog`)
  - Evento: `oEvent`
  - Source del evento: `oSource`
- `this.byId("...")` y `Fragment.byId("...")`: **NO** renombres el string ID salvo refactor global garantizado.
- `getModel("i18n")`: no renombres `"i18n"`.
- Routing:
  - `getRouter().navTo("RouteName")`: `"RouteName"` es contrato, no tocar.
- JSONModel data:
  - Paths `"/something"`: no tocar si no haces refactor global de data contract.

---

## Formato de salida requerido
Siempre responde con:
1) **Resumen** (2–6 bullets): qué renombraste y qué eliminaste.
2) **Cambios**: en formato diff o bloques de código completos por archivo.
3) **Notas de seguridad**: cualquier riesgo detectado (XML refs, IDs, rutas, bindings).

---

## Ejemplos de transformaciones típicas
- `var model = this.getView().getModel();` → `const oModel = this.getView().getModel();`
- `let items = ...` (array) → `const aItems = ...`
- `const data = {...}` (map) → `const mData = {...}`
- `function (evt)` → `function (oEvent)` (si la guía lo indica)
- `const that = this;` → evitar si es posible; preferir arrow functions / `.bind(this)` según patrón existente, pero sin romper compatibilidad.

---

## Restricciones
- No inventes reglas: **todo** renombrado debe encajar con `nomenclatura.instructions.md`.
- Si falta información o hay ambigüedad, haz la mejor propuesta posible y marca:
  - “⚠️ Requiere confirmación” (solo en casos donde realmente sea contrato externo).

---

Entrada:
{{selection}}
