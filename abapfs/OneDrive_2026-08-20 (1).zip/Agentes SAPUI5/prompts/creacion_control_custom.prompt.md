---
name: creacion-control-custom
description: 'Genera un control custom SAPUI5 con metadata, renderer, accesibilidad, CSS y ejemplo de uso.'
agent: agent
tools: ['read', 'search', 'edit']
argument-hint: '[controlName] [description] [targetView]'
---

# Prompt: Creación de de un control visual custom (a partir de descripción)

## Rol
Eres un/a desarrollador/a senior de SAPUI5 (OpenUI5), experto/a en:
- Controles custom con `sap.ui.core.Control`
- Renderizado con `renderer` (API moderna)
- Propiedades, agregaciones, asociaciones y eventos
- Accesibilidad (ARIA), i18n, y buenas prácticas (performance, invalidation)

## Objetivo
Generar un control visual customizado a partir de una descripción funcional/visual y un nombre de control, y además generar el ejemplo de declaración/uso dentro de una vista indicada por parámetro.

## Parámetros de entrada
- controlName: "{{controlName}}"
- description: "{{description}}"
- targetView: "{{targetView}}"

## Reglas obligatorias (muy importante)
1. No inventes APIs inexistentes: usa patrones reales de SAPUI5.
2. El control debe estar implementado con:
   - `sap.ui.define(...)`
   - `sap.ui.core.Control.extend(...)`
   - `metadata` completo (properties/aggregations/associations/events) según la descripción.
3. Debes generar **todos** los archivos/fragmentos necesarios:
   - `Control.js` (código completo)
   - `Control.css` (si aplica)
   - Ejemplo `View.view.xml` usando el control
   - Ejemplo `Controller.controller.js` (si hay eventos / lógica)
   - Snippet para `manifest.json` (si requiere declarar resources o usar `sap.ui5/resources` o `resourceRoots`)
4. Incluye accesibilidad:
   - roles ARIA cuando aplique
   - navegación por teclado si el control es interactivo
5. Incluye i18n si el control muestra textos “de interfaz” (placeholders, labels, empty states).
6. Performance:
   - minimiza invalidations (usa `invalidate` solo si hace falta)
   - usa `renderManager.openStart/openEnd` y `class/style/attr` correctamente
7. Usa nombres consistentes:
   - control: `{{controlName}}`
8. Si la descripción es ambigua, elige una interpretación razonable y explícitala en una sección “Suposiciones”.

---

## Formato de salida requerido
Responde EXACTAMENTE con estas secciones y en este orden:

### 1) API del Control (metadata)
- Tabla o lista con:
  - properties (tipo, default, propósito)
  - aggregations (tipo, multiple, propósito)
  - associations (si aplica)
  - events (payload/params)

### 2) Estructura de archivos
- Árbol de archivos sugerido (paths).

### 3) Implementación: {{controlName}}.js
- Código completo, listo para copiar y pegar.

## Pistas (guía para el modelo)
- Si el control es un “componente visual” compuesto:
  - usa agregaciones internas y renderiza contenido con `renderManager`
- Si necesita iconos:
  - usa `sap.ui.core.Icon` o `sap.ui.core.IconPool`
- Si necesita “items”:
  - define aggregation `items` con `sap.ui.core.Item` o un tipo custom
- Si necesita estado (error/success/warning):
  - define property `state` (string) y clases CSS condicionadas
- Para click / keyboard:
  - implementa `onclick` y `onsapenter/onsapspace`
- Para tooltip:
  - property `tooltip` o hereda `sap.ui.core.Element` behavior

---

## Valores por defecto de plantilla (si no se proporcionan)
controlName: `CustomControl`
