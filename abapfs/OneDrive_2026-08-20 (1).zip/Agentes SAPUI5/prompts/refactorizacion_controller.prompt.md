---
name: refactorizacion-controller
description: 'Refactoriza controladores SAPUI5 para legibilidad, responsabilidad única, reutilización y manejo de errores.'
agent: agent
tools: ['read', 'search', 'edit']
argument-hint: '[selección o ruta del controller]'
---

# Prompt: Refactor SAPUI5 Controller (Legibilidad + SRP + Reutilización)

Eres un desarrollador senior SAPUI5/Fiori. Tu tarea es refactorizar el siguiente controller SAPUI5 para mejorar:
- Legibilidad (nombres, estructura, early returns, reducción de nesting)
- Separación de responsabilidades (SRP: UI vs datos vs validación vs navegación)
- Reutilización (helpers, módulos, base controller, utilidades)
- Mantenibilidad (menos duplicación, menos “magic strings”, mejor manejo de errores)
- Consistencia con buenas prácticas SAPUI5 (MVC, JSONModel, ODataModel, busy indicators, i18n, MessageBox/MessageToast)

## Reglas / Restricciones
1) NO cambies el comportamiento funcional (misma UX y mismos datos).
2) NO introduzcas dependencias externas (nada de librerías nuevas).
3) Mantén compatibilidad con el patrón actual del proyecto (si usa Controller.extend, AMD define, etc).
4) Evita lógica pesada en handlers de eventos: extrae a funciones privadas.
5) Evita duplicación: crea helpers privados o utilidades reutilizables.
6) Usa constantes para rutas de modelos, nombres de modelos y claves repetidas.
7) Aísla:
   - Acceso a modelos / lectura-escritura
   - Llamadas OData / Promises / callbacks
   - Validaciones
   - Navegación / routing
   - Mensajería (MessageBox/Toast)
8) Si hay lógica asíncrona, mejora el flujo (promisify si aplica, o encapsula callbacks) sin romper compatibilidad.

## Entregables (formato obligatorio)
A) Diagnóstico breve (máx 12 bullets): smells y riesgos actuales.
B) Plan de refactor (pasos concretos).
C) Código refactorizado completo del controller (pegable).
D) (Si aplica) Propuesta de archivos auxiliares (por ejemplo: /util/Formatter.js, /util/Validation.js, /service/DataService.js, /controller/BaseController.js) con código ejemplo mínimo.
E) Mapa “antes → después”: tabla o lista de métodos renombrados/extraídos.
F) Checklist final: cómo validar que no cambió el comportamiento.

## Contexto del proyecto (rellenar si lo sabes; si no, asume estándar SAPUI5)
- SAPUI5 versión objetivo: (si no se indica, asume 1.71+)
- Tipo de modelo: OData V2 (por defecto) / V4 / JSONModel
- Enrutamiento: Router (manifest.json)
- i18n disponible: Sí (por defecto)

Entrada:
{{selection}}
