---
name: actualizacion-i18n
description: 'Limpia, agrupa y completa claves i18n SAPUI5 manteniendo case sensitivity y formato .properties.'
agent: agent
tools: ['read', 'search', 'edit']
argument-hint: '[selección o ruta del fichero i18n]'
---

# Prompt: Limpiar y agrupar traducciones i18n por fichero (case sensitive)

Actúa como un desarrollador senior experto en SAPUI5.

Objetivo:
Limpiar el fichero i18n seleccionado eliminando traducciones duplicadas, ordenando las traducciones según el fichero en el que se utilizan y añadiendo las traducciones de los códigos que no se han generado

Reglas CRÍTICAS:zº
- El fichero i18n es **case sensitive**
- `KEY=value` y `key=value` son claves distintas
- NO modifiques los valores de las traducciones
- NO cambies las claves
- NO cambies el encoding
- NO reformatees espacios innecesariamente
- Mantén el formato `.properties`

Eliminación de duplicados:
- Una traducción es duplicada si la clave es exactamente igual (mismo case)
- Mantén la primera aparición
- Elimina las repeticiones posteriores
- Ignora líneas vacías y comentadas (`#`)

Generación traducciones:
- Generar traducciones en el fichero i18n que se usan en vistas o controladores pero que no se han generado todavía. 

Ordenación y agrupación:
- Agrupa las traducciones por el fichero donde se utilizan
- El orden de los grupos debe seguir el orden real de uso en el proyecto
- Dentro de cada grupo, conserva el orden original
- Si no puedes determinar el fichero de uso con seguridad, agrupa la traducción bajo el comentario:
  `# File: Unknown`

Comentarios:
- Añade un comentario antes de cada grupo con el nombre del fichero
- Formato exacto del comentario:
  `# File: <nombre_del_fichero>`

Restricciones:
- NO elimines comentarios existentes
- NO añadas comentarios extra fuera de los encabezados de fichero
- Si una traducción se usa en varios ficheros, colócala en el primero donde aparezca

Entrada:
{{selection}}

Salida esperada:
- Fichero i18n limpio
- Traducciones agrupadas por fichero
- Comentarios de fichero añadidos
- Sin texto explicativo fuera del contenido
