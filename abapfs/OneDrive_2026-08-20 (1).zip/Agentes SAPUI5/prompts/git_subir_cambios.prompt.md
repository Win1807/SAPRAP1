---
name: git-subir-cambios
description: 'Crea commit y push seguros de cambios locales, con rollback suave si el push es rechazado.'
agent: agent
tools: ['execute']
argument-hint: '[mensaje de commit opcional]'
---

# Prompt: SAPUI5 – Subir cambios pendientes a Git (con rollback si hay conflicto)

Eres un asistente dentro de VSCode trabajando en un proyecto SAPUI5 (UI5 Tooling).
Objetivo: subir cambios pendientes al repositorio remoto Git de forma segura.  
Requisitos:
- Solo actuar si hay cambios locales.
- Crear commit con un mensaje razonable si el usuario no lo dio.
- Intentar `push`.
- Si el `push` falla por conflictos/no-fast-forward, revertir el commit local y dejar los cambios disponibles localmente (sin perder trabajo).
- Mostrar un mensaje claro de éxito o de rollback.
- No borrar archivos ni hacer rebase/merge automático sin pedirlo.

## Pasos (estrictos)

1) Verifica que el directorio es un repo Git:
- Ejecuta: `git rev-parse --is-inside-work-tree`
- Si falla: muestra “No estoy en un repositorio Git. Aborta.”

2) Comprueba si hay cambios:
- Ejecuta: `git status --porcelain`
- Si no hay salida: muestra “No hay cambios pendientes. Nada que subir.” y termina.

3) Determina rama actual y remoto:
- Rama: `git branch --show-current`
- Remoto preferido: `origin` si existe (comprueba con `git remote`)
- Si no hay remoto: muestra “No hay remoto configurado. Configura un remote (ej. origin) y reintenta.” y termina.

4) Preparación segura antes de commitear:
- Muestra un resumen breve: archivos modificados/añadidos (usa `git status -sb`).
- NO hagas `git pull` automático.
- Si hay cambios sin stage, añade todo:
  - `git add -A`

5) Crea commit:
- Si el usuario no proporcionó mensaje, usa:  
  `chore(ui5): update SAPUI5 app`
- Ejecuta: `git commit -m "<MENSAJE>"`

6) Intenta push:
- Ejecuta: `git push <REMOTE> <BRANCH>`

7) Manejo de error (conflicto/no-fast-forward):
- Si `git push` devuelve error del tipo:
  - “non-fast-forward”
  - “fetch first”
  - “rejected”
  - “Updates were rejected”
  entonces:
  a) Revierte el commit local recién creado SIN perder cambios:
     - `git reset --soft HEAD~1`
     - (opcional) deja el index limpio si hace falta:
       - `git reset`  (para pasar staged -> unstaged)
  b) Muestra un mensaje:
     - “❌ Push rechazado por cambios en remoto (non-fast-forward). He revertido el commit local y tus cambios siguen en tu working tree. Sugerencia: ejecuta `git pull --rebase` o `git pull` y resuelve conflictos; luego vuelve a intentar.”
  c) Termina.

8) Éxito:
- Si el push funciona:
  - Muestra “✅ Cambios subidos correctamente a <REMOTE>/<BRANCH>.”

## Reglas de seguridad
- Nunca uses `git push --force` ni `--force-with-lease`.
- No ejecutes `git pull`, `merge` o `rebase` automáticamente.
- No elimines cambios del usuario: ante fallo, usar `git reset --soft` para conservar trabajo.

## Salida final esperada
- Un mensaje final (éxito o rollback) y, si aplica, un comando sugerido para sincronizar con remoto.
