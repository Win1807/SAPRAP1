---
name: generacion-tests
description: 'Genera tests SAPUI5 OPA5 y QUnit con page objects, journeys, runner y scripts de ejecución.'
agent: agent
tools: ['read', 'search', 'edit']
argument-hint: '[vista o flujo funcional a cubrir]'
---

# Prompt: Generación de Tests Integrados (OPA5 + QUnit) para aplicación SAPUI5

Eres un/a desarrollador/a senior SAPUI5 y especialista en testing (QUnit + OPA5). Debes generar **tests integrados (integration tests)** para una aplicación SAPUI5 siguiendo buenas prácticas, con código listo para ejecutar.

# Objetivo
Crear una suite completa de **OPA5 integration tests** que cubra:
- Arranque de la app (arranque del component + router)
- Navegación principal entre vistas
- Validación de elementos clave (controles, textos, botones)
- Flujo feliz (happy path) de usuario
- Al menos 1 caso negativo (validación/error)
- Mocking de backend cuando aplique (MockServer) o recomendaciones concretas si no es posible

# Contexto de la app
## Framework y versión
- SAPUI5/OpenUI5: <PONER_VERSION_SI_SE_CONOCE>
- Tipo de proyecto: <Fiori elements / freestyle SAPUI5>
- Estructura (si existe): webapp/, test/, localService/

## Rutas y Vistas (rellenar)
- Ruta inicial: <ej. "main" o "" >
- Vistas:
  - <View1> (controller: <Controller1>)
  - <View2> (controller: <Controller2>)
- Navegación:
  - Desde <View1> a <View2> mediante <botón/link/control id?>

## Controles y IDs relevantes (rellenar)
Incluye IDs reales si existen. Si no, usa matchers robustos (controlType + properties).
- Botón principal: <id o texto>
- Tabla/lista: <id>
- Campo input: <id>
- Botón “Guardar/Enviar”: <id o texto>
- Mensaje de error esperado: <texto>

## Datos / Backend
- OData: <v2/v4> (si aplica)
- Service URL: <si aplica>
- ¿MockServer existente?: <sí/no>
- Entidades clave: <EntitySet1, EntitySet2>

# Reglas estrictas
1. Genera tests usando **OPA5 + QUnit** (no wdio).
2. Usa page objects: `test/integration/pages/<Nombre>.js`
3. Centraliza el arranque en `test/integration/AllJourneys.js` y/o `arrangements/Startup.js`.
4. No inventes IDs si te doy IDs: respétalos.
5. Si faltan IDs, usa selectores robustos: `controlType`, `viewName`, `bindingPath`, `i18n` cuando sea posible.
6. Debes incluir TODO el código necesario: ficheros y contenido completo.
7. Mantén el código compatible con UI5 Tooling + karma o runner clásico (explica ambos si es necesario).

# Entregables
Genera:
- `test/integration/AllJourneys.js`
- `test/integration/arrangements/Startup.js` (si aplica)
- `test/integration/pages/<Page1>.js`
- `test/integration/pages/<Page2>.js` (si aplica)
- `test/integration/journeys/<Journey>.js` (mínimo 2 journeys)
- `test/testsuite.qunit.html` o configuración equivalente
- Ajustes necesarios en `manifest.json` y/o `karma.conf.js` si aplica (solo lo imprescindible)

# Cobertura mínima requerida (defínela y cúmplela)
- Journey 1: “Arranca app y se muestra <View1> con elementos clave”
- Journey 2: “Navega a <View2>, interactúa con <control>, verifica resultado”
- Caso negativo: “Introduce dato inválido, verifica MessageBox/MessageToast/ValueState”

# Formato de salida
Devuelve el resultado como:
1) Lista de archivos
2) Bloques de código por archivo con ruta como título
3) Notas finales: cómo ejecutar localmente (npm scripts / ui5 serve / karma)

# Ejecución de los tests
Además de generar los tests, debes:

1. Generar los scripts necesarios para ejecutar los tests de integración:
   - Opción A: UI5 Tooling (ui5 serve)
   - Opción B: Karma (headless Chrome)

2. Incluir:
   - Scripts npm en `package.json`
   - (Opcional) `karma.conf.js`
   - URL exacta para ejecutar OPA5 en navegador

3. Explicar claramente:
   - Cómo ejecutar los tests en local
   - Cómo ejecutarlos en modo headless (CI/CD)

4. Si es posible, generar una VS Code Task (`.vscode/tasks.json`)
   para ejecutar los tests con un solo click.

No ejecutes nada tú mismo, pero deja el proyecto listo para ejecución inmediata.
