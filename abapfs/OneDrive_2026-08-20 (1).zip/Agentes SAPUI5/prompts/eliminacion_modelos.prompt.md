---
name: eliminacion-modelos
description: 'Detecta y elimina modelos SAPUI5 no utilizados en manifest, Component, vistas y controladores.'
agent: agent
tools: ['read', 'search', 'edit']
argument-hint: '[alcance o carpeta SAPUI5]'
---

# Prompt: Eliminación de modelos de datos no utilizados en SAPUI5

Actúa como un desarrollador senior especializado en SAPUI5 y arquitectura MVC.

Objetivo:
Identificar y eliminar modelos de datos que no estén siendo utilizados en ninguna vista ni controlador del proyecto SAPUI5.

Contexto del proyecto:
- Framework: SAPUI5
- Patrón: MVC
- Estructura típica:
  - /webapp/controller/*.controller.js
  - /webapp/view/*.view.xml
  - /webapp/model/*
  - manifest.json
  - Component.js

Tareas a realizar:
1. Analiza el archivo manifest.json para identificar:
   - Modelos definidos en la sección "models".
   - Modelos globales y con nombre (named models).

2. Analiza Component.js para detectar:
   - Modelos creados dinámicamente mediante new sap.ui.model.*
   - setModel(...) en el componente.

3. Recorre todos los controladores (*.controller.js) y detecta:
   - Uso de getModel(), getView().getModel(), this.getOwnerComponent().getModel()
   - Accesos a modelos con y sin nombre
   - Bindings programáticos (bindElement, bindItems, bindProperty, etc.)

4. Recorre todas las vistas XML (*.view.xml) y detecta:
   - Data binding (ej. {modelName>/path})
   - Uso de modelos por defecto y con nombre
   - Agregaciones y propiedades enlazadas

5. Determina qué modelos:
   - ❌ NO están referenciados en ninguna vista ni controlador
   - ✅ Están activos y en uso

6. Para cada modelo NO utilizado:
   - Indica el archivo donde está definido
   - Explica por qué se considera no usado
   - Propón su eliminación segura

7. Aplica los cambios:
   - Elimina el modelo del manifest.json y/o Component.js
   - No rompas dependencias existentes
   - No elimines modelos usados indirectamente (ej. por fragmentos si existen)

Formato de salida:
- Lista de modelos eliminables
- Archivos afectados
- Diff o ejemplo de código antes/después
- Advertencias si hay dudas sobre uso indirecto

Restricciones:
- No modificar lógica funcional existente
- No eliminar modelos usados en fragmentos, extensiones o carga dinámica sin confirmación
- Mantener compatibilidad con SAPUI5 estándar

Idioma de la respuesta:
- Español técnico claro
