# Configuración Copilot SAPUI5

Este directorio contiene personalizaciones de GitHub Copilot para proyectos SAPUI5/Fiori:

- Instrucciones globales y por tipo de archivo.
- Agentes especializados para generación, documentación, traducción, validación y PLP.
- Prompt files reutilizables como slash commands.
- Skills SAPUI5 y skills auxiliares para documentos Office/PDF.

## Instalación

1. Copia el contenido de este directorio en la carpeta `.github/` del repositorio SAPUI5.
2. La estructura final debe quedar así:

```text
.github/
├── copilot-instructions.md
├── instructions/
├── agents/
├── prompts/
├── skills/
└── skills-lock.json
```

No instales la carpeta con el nombre `.github_apr-main`; Copilot espera `.github/`.

## Versión y capacidades esperadas

Usa una versión actual de GitHub Copilot que soporte:

- Repository custom instructions: `.github/copilot-instructions.md`.
- Path-specific instructions: `.github/instructions/*.instructions.md`.
- Prompt files: `.github/prompts/*.prompt.md`.
- Custom agents: `.github/agents/*.agent.md` o `.github/agents/*.md`.
- Agent skills: `.github/skills/<skill-name>/SKILL.md`.

Para gestión de skills con GitHub CLI, usa `gh` 2.90.0 o superior y revisa `gh skill --help`.

## Dependencias recomendadas

- Node.js y npm compatibles con el proyecto SAPUI5.
- UI5 Tooling si el proyecto se ejecuta con `ui5 serve`, `npm start` o scripts equivalentes.
- Mermaid CLI para generar PNG desde diagramas Mermaid:

```bash
npm install --save-dev @mermaid-js/mermaid-cli
```

El comando esperado por el agente de documentación es:

```bash
npx mmdc -i docs/diagrams/flow.mmd -o docs/diagrams/flow.png -b transparent
```

## MCP UI5

`copilot-instructions.md` recomienda usar la herramienta `get_guidelines` del servidor UI5 MCP cuando esté disponible. Si no tienes ese MCP configurado, la instrucción debe interpretarse como opcional: Copilot debe continuar con las guías locales y marcar cualquier supuesto.

Cuando configures un MCP para Copilot, documenta su instalación en el repositorio o en la configuración local del equipo. Evita depender de herramientas globales no documentadas.

## Cómo invocar agentes

En Copilot Chat o Copilot Agent Mode, selecciona el agente desde el selector de agentes cuando esté disponible:

- `Orquestador SAPUI5`: coordina la generación end-to-end de una vista.
- `Agente Interfaz SAPUI5`: crea vistas XML y CSS.
- `Agente Lógica SAPUI5`: implementa controladores, modelos y OData.
- `Agente Navegación SAPUI5`: actualiza routing y `manifest.json`.
- `Agente Traducciones SAPUI5`: gestiona i18n.
- `Agente Documentación SAPUI5`: genera JSDoc, Mermaid y documentación.
- `Agente Validación SAPUI5`: genera casos y checklist de pruebas.
- `Agente PLP SAPUI5`: genera planes de prueba en CSV.

Nota de compatibilidad: la propiedad `handoffs` del orquestador se conserva para IDEs que la soporten. GitHub.com / Copilot cloud agent la ignora actualmente; en ese entorno, invoca el agente especializado manualmente o permite que el orquestador use la herramienta `agent` si está disponible.

## Cómo invocar prompts

Los ficheros de `.github/prompts/*.prompt.md` aparecen como slash commands. Ejemplos:

- `/generacion-dt`: genera un diseño técnico del proyecto.
- `/generacion-tests`: crea tests OPA5/QUnit.
- `/variable-management`: renombra variables y elimina no usados.
- `/actualizacion-i18n`: limpia y agrupa traducciones.
- `/git-subir-cambios`: commit y push seguro.
- `/git-merge-main`: merge seguro a `main`.

## Cómo se cargan las skills

Copilot descubre las skills por el frontmatter de cada `SKILL.md`. Los campos críticos son:

- `name`: debe coincidir con el nombre de la carpeta.
- `description`: debe explicar qué hace la skill y cuándo usarla.

Puedes invocarlas manualmente como slash commands si el host lo soporta, por ejemplo:

- `/sapui5-dev-assistant`
- `/sapui5-binding-debugger`
- `/sapui5-decimal-input`
- `/sapui5-masterdata-dropdown-binding`

También pueden activarse automáticamente cuando la descripción coincide con la petición del usuario.

## Mantenimiento

- Mantén `skill.json` solo como metadata auxiliar o compatibilidad histórica; el cargador principal usa `SKILL.md`.
- Evita instrucciones contradictorias entre `copilot-instructions.md` e instrucciones path-specific.
- Si añades prompts, incluye frontmatter con `name`, `description`, `agent`, `tools` y `argument-hint`.
- Si añades skills, valida que `name` sea kebab-case y coincida con la carpeta.
