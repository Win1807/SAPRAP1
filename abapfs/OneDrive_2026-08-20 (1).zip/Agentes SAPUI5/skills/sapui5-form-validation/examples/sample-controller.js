sap.ui.define([
    "sap/ui/core/mvc/Controller"
], function (Controller) {
    "use strict";

    return Controller.extend("your.namespace.controller.Sample", {

        _validateForm: function () {
            const bMandatory = this._validateMandatoryFields(this.getView());
            const bFormat = this._validateFormatFields(this.getView());

            return bMandatory && bFormat;
        },

        onPressGuardar: function () {
            if (!this._validateForm()) {
                return;
            }
        }
    });
});
