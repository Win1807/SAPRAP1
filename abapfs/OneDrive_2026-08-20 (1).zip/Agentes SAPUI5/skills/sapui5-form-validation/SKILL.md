---
name: sapui5-form-validation
description: >
  Valida formularios SAPUI5 en controladores: modifica onPressGuardar()
  para llamar a _validateForm() y detener la ejecución si hay errores.
  _validateForm() combina validación de obligatorios y formato.
user-invocable: true
disable-model-invocation: false
metadata:
  display_name: SAPUI5 Validación de Formulario
  version: "1.0.0"
  language: es
  platforms: [vscode, cli]
  categories: [sapui5, sap, ui5, validation, form]
---

# SAPUI5 Validación de formulario en onPressGuardar — instrucciones para el agente

## Propósito
Configurar automáticamente la validación de un formulario en un controlador SAPUI5 para que `onPressGuardar()` llame a `_validateForm()` y, si el formulario no es correcto, **no continúe con la ejecución**.
---

## Reglas / Principios
1. **Inyección obligatoria en `onPressGuardar()`**: asegurar que la función `onPressGuardar()` ejecute al inicio:
   - `if (!this._validateForm()) { return; }`
2. **Función `_validateForm()` obligatoria**: asegurar que exista `_validateForm()` en el controlador con el patrón estándar.
3. **Validación de obligatorios**: `_validateForm()` debe llamar a:
   - `this._validateMandatoryFields(this.getView())`
4. **Validación de formato**: `_validateForm()` debe llamar a:
   - `this._validateFormatFields(this.getView())`
5. **Resultado combinado**: `_validateForm()` debe devolver `true` solo si ambas validaciones son correctas:
   - `return bMandatory && bFormat;`
6. **No continuar si inválido**: si `_validateForm()` devuelve `false`, `onPressGuardar()` debe finalizar inmediatamente con `return;`.
7. **Reemplazo seguro**: si `onPressGuardar()` ya tiene lógica previa, **no duplicar** la validación; **inyectar** el guard clause al inicio manteniendo cambios mínimos.
8. **Funciones existentes**: si `_validateForm()` ya existe, **no recrearla**; ajustar su contenido solo si no cumple el patrón (cambios mínimos).
9. **No inventar validadores**: no crear `_validateMandatoryFields()` ni `_validateFormatFields()` si no existen; `_validateForm()` debe asumir que están disponibles en el controlador/base.
10. **Estilo SAPUI5**: mantener el estilo de métodos del controlador (objetos/literales) y no cambiar firmas.
---

## Triggers y cuándo usar la skill
- Activar si el prompt contiene frases como: **"validar que el formulario sea correcto"**, **"validar formulario"**, **"validar campos"**, **"campos obligatorios"**, **"validar formato"**, **"onPressGuardar"**, o peticiones semánticamente equivalentes.
- Activar si el usuario pide explícitamente que el guardado se detenga si hay errores de validación.
---

## Plantillas completas (archivos)
Para aplicar el patrón, el agente debe producir el **código del controlador modificado** siguiendo estas plantillas.

## Plantilla (archivos)
Para plantillas completas usa los ficheros en `examples/`:

- `examples/sample-controller.js` — Código con la lógica a añadir en el controlador.
