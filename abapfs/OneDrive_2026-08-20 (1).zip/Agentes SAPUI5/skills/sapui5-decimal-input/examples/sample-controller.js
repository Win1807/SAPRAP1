sap.ui.define([
    "sap/ui/core/mvc/Controller"
], function (Controller) {
    "use strict";

    return Controller.extend("your.namespace.controller.App", {
        _onDecimalComma2LiveChange: function (oEvent) {
            var oInput = oEvent.getSource();
            var sValue = oEvent.getParameter("value");

            // 1) Permitir solo dígitos y coma
            sValue = (sValue || "").replace(/[^\d,]/g, "");

            // 2) Una sola coma: conservar la primera
            var iFirstComma = sValue.indexOf(",");
            if (iFirstComma !== -1) {
                var sInt = sValue.slice(0, iFirstComma);
                var sFracRaw = sValue.slice(iFirstComma + 1).replace(/,/g, "");
                var sFrac = sFracRaw.slice(0, 2); // 3) Máximo 2 decimales
                sValue = sInt + "," + sFrac;
            }

            // 4) Escribir solo si cambió (evita parpadeo)
            if (oInput.getValue() !== sValue) {
                oInput.setValue(sValue);
            }
        }
    });
});