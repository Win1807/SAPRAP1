---
name: sapui5-decimal-input
description: >
  Configura un sap.m.Input para aceptar únicamente números decimales positivos
  con coma como separador y máximo dos decimales. Usar para campos de importe,
  decimal, solo números y coma, sin negativos y con validación en liveChange.
user-invocable: true
disable-model-invocation: false
metadata:
  display_name: SAPUI5 Input Decimal (coma)
  version: "1.0.0"
  language: es
  platforms: [vscode, cli]
  categories: [sapui5, sap, ui5, input, validation]
---

# SAPUI5 Input decimal (coma) en sap.m.Input — instrucciones para el agente

## Propósito
Configurar un campo **específico** `sap.m.Input` en una vista SAPUI5 (XMLView) para que acepte **solo**:
- Dígitos (`0-9`) y **coma** (`,`) como separador decimal
- **Sin negativos** (no permitir `-`)
- **Máximo una coma**
- **Máximo 2 dígitos** después de la coma

La validación debe ocurrir **mientras el usuario escribe** (si introduce un carácter no permitido, **no debe escribirse**).

## Reglas / Principios
1. **Aplicar solo al campo indicado:** modificar únicamente el `sap.m.Input` especificado por el usuario (por `id` o por ruta de binding `value`).
2. **No cambiar el tipo a `Number`:** no usar `type="Number"` (permite caracteres no deseados como `-`, `e`, etc.). Mantener `type="Text"` si existe o establecerlo a `Text` si fuera necesario.
3. **Filtro en tiempo real:** usar `liveChange` + `valueLiveUpdate="true"` para sanitizar el valor mientras se escribe.
4. **Sanitizado estricto:** permitir únicamente `0-9` y `,`. Eliminar cualquier otro carácter.
5. **Sin negativos:** eliminar cualquier `-` y cualquier intento de introducirlo.
6. **Una sola coma:** si hay más de una coma, mantener solo la **primera**.
7. **Máximo 2 decimales:** si existe coma, recortar a **2** caracteres tras la coma.
8. **No alterar otros atributos:** no tocar estructura, namespaces, bindings existentes (salvo el campo objetivo) ni otras propiedades. Solo insertar/actualizar los atributos requeridos y el handler en el controller si falta.
9. **Handler idempotente:** si el `sap.m.Input` ya tiene `liveChange`, **reemplazarlo** por el handler definido por esta skill (no mantener alternativos).
10. **Implementación en controller:** si el método handler no existe, crearlo en el controller correspondiente. Si ya existe, actualizarlo para cumplir estas reglas exactas.
11. **Sin mensajes/validación extra:** no añadir `ValueState`, `MessageToast`, ni lógica adicional. Solo impedir que se escriban caracteres no permitidos (mediante setValue del valor saneado).

---

## Triggers y cuándo usar la skill
- Activar si el prompt contiene frases como: **"decimal"**, **"importe decimal"**, **"sap.m.Input decimal"**, **"solo números y coma"**, **"dos decimales"**, **"no negativos"**, **"una sola coma"** o peticiones semánticamente equivalentes.
- Activar si el usuario indica un campo concreto (por `id` del Input o por ruta de binding en `value`) y solicita comportamiento decimal con coma y 2 decimales.

---

## Plantillas completas (archivos)

### XML de la vista (insertar/actualizar SOLO en el `sap.m.Input` objetivo)
```xml
<...:Input
  ...
  type="Text" valueLiveUpdate="true" liveChange="._onDecimalComma2LiveChange" />
```

## Plantilla (archivos)
Para plantillas completas usa los ficheros en `examples/`:

- `examples/sample-controller.js` — Código con la lógica a añadir en el controlador App.controller (en caso de que la función ya exista, no modificarla).
