sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/json/JSONModel",
    "sap/m/MessageBox",
    "path/to/manageDB" // <-- ajusta este path
], function (Controller, JSONModel, MessageBox, manageDB) {
    "use strict";

    return Controller.extend("your.namespace.controller.Sample", {

        _onRouteMatched: function (oEvent) {
            this._setLocalModels();
            this._loadMasterData();
        },

        _setLocalModels: function () {
            const oMasterDataModel = new JSONModel({ /* {prop}: [] por cada desplegable */ });
            oMasterDataModel.setSizeLimit(1000000);
            this.getView().setModel(oMasterDataModel, "masterData");
        },

        _loadMasterData: function () {
            const oMasterDataModel = this.getView().getModel("masterData");

            this.getView().setBusy(true);
            Promise.all([
                manageDB.getEntitySetData(this.getView().getModel(), "<entitySet1>").then((aData) => {
                    oMasterDataModel.setProperty("/{prop1}", aData);
                    return aData;
                }),
                manageDB.getEntitySetData(this.getView().getModel(), "<entitySet2>").then((aData) => {
                    oMasterDataModel.setProperty("/{prop2}", aData);
                    return aData;
                })
            ]).then(() => {
                this.getView().setBusy(false);
            }).catch((oError) => {
                this.getView().setBusy(false);
                MessageBox.error(this.getText("DB_ERROR_LOADING_MASTER_DATA") + ": " + oError.message);
            });
        }

    });
});
