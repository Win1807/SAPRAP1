---
name: sapui5-masterdata-dropdown-binding
description: >
  Genera bindings de items para sap.m.Select y sap.m.ComboBox y añade
  lógica de carga masterData en el controlador mediante manageDB.getEntitySetData().
  Usar para desplegables, ComboBox, Select, masterData, items aggregation y OData entity sets.
user-invocable: true
disable-model-invocation: false
metadata:
  display_name: SAPUI5 MasterData Dropdown Binding
  version: "1.0.0"
  language: es
  platforms: [vscode, cli]
  categories: [sapui5, sap, ui5, odata, binding, select]
---

# SAPUI5 Bind items + carga masterData en Select/ComboBox — instrucciones para el agente

## Propósito
Configurar automáticamente la agregación `items` en controles **`sap.m.Select`** y **`sap.m.ComboBox`** de una vista SAPUI5 (XMLView), bindeándola al modelo local de vista `masterData` y generando la lógica de controlador necesaria para cargar los datos desde **OData** mediante `manageDB.getEntitySetData()`.
---

## Reglas / Principios
1. **Aplicar a todos los desplegables mapeados**: por cada mapeo “desplegable → entity set OData”, configurar el control correspondiente (`sap.m.Select` o `sap.m.ComboBox`) con su binding de `items`.
2. **Binding estándar obligatorio en `items`**: el atributo `items` debe quedar como binding string al modelo `masterData` con la ruta `masterData>/{prop}`.
3. **Item template obligatorio**: dentro del control, incluir siempre un `<core:Item .../>` con `key` y `text` bindeados al modelo `masterData` (`{masterData>...}`).
4. **Modelo local obligatorio**: en el controlador, crear (o actualizar) el modelo JSON de la vista `"masterData"` en `_setLocalModels()` con **una propiedad array por cada desplegable**.
5. **Ejecución en ruta**: en `_onRouteMatched()` llamar siempre a:
   - `this._setLocalModels();`
   - `this._loadMasterData();`
6. **Carga con promesas**: en `_loadMasterData()` usar `Promise.all([ ... ])` con una llamada por cada entity set:
   - `manageDB.getEntitySetData(this.getView().getModel(), "<entitySet>")`
   - `oMasterDataModel.setProperty("/<prop>", aData)`
7. **Gestión de busy obligatoria**: envolver la carga con:
   - `this.getView().setBusy(true);` antes de `Promise.all`
   - `this.getView().setBusy(false);` en `then` y `catch`
8. **Gestión de error fija**: en `catch`, mostrar siempre:
   - `MessageBox.error(this.getText("DB_ERROR_LOADING_MASTER_DATA") + ": " + oError.message);`
9. **Reemplazo seguro**: si el control ya tiene `items` o un template diferente, **reemplazarlo** por el patrón estándar.
10. **No inventar entity sets**: usar exactamente los proporcionados por el usuario (p. ej. `/ddTiposSociedad`).
11. **Nombres de propiedades en `masterData`**: usar **camelCase** coherente y estable por cada desplegable (p. ej. `tiposSociedad`, `codigoCNAE`).
12. **Namespaces mínimos**: no alterar estructura; sólo asegurar que exista `xmlns:core="sap.ui.core"` si se necesita para `<core:Item>`.
13. **Funciones existentes**: si `_setLocalModels()` y/o `_loadMasterData()` **ya existen**, **no crearlas**; **añadir/inyectar la lógica necesaria** respetando el código existente, manteniendo cambios mínimos y sin duplicar comportamiento.
---

## Triggers y cuándo usar la skill
- Activar si el prompt contiene frases como: **"configurar items"**, **"bindear items"**, **"desplegables"**, **"sap.m.Select"**, **"sap.m.ComboBox"**, **"cargar masterData"**, **"OData entity set"**, **"ddTipos"**, **"getEntitySetData"** o peticiones semánticamente equivalentes.
- Activar si el usuario aporta explícitamente una lista de mapeos del tipo: **“El desplegable X mapeará contra la entidad /... del oData”**.
---

## Plantillas completas (archivos)
Para aplicar el patrón, el agente debe producir el **XML de la vista modificado** y el **código del controlador** siguiendo estas plantillas.

## Plantilla (archivos)
Para plantillas completas usa los ficheros en `examples/`:

- `examples/sample-controller.js` — Código con la lógica a añadir en el controlador.

### Plantilla XML (Select/ComboBox)

```xml
<ComboBox items="{masterData>/{prop}}">
    <core:Item key="{masterData>{KEY_FIELD}}" text="{masterData>{TEXT_FIELD}}"/>
</ComboBox>

<Select items="{masterData>/{prop}}">
    <core:Item key="{masterData>{KEY_FIELD}}" text="{masterData>{TEXT_FIELD}}"/>
</Select>
```
