---
name: sapui5-year-datepicker
description: >
  Añade o ajusta en una vista SAPUI5 XML un sap.m.DatePicker que solo permita
  introducir años usando displayFormat="yyyy" y placeholder=" ".
  Usar para selector de año, DatePicker solo año o displayFormat yyyy.
user-invocable: true
disable-model-invocation: false
metadata:
  display_name: SAPUI5 DatePicker Solo Año (yyyy)
  version: "1.0.0"
  language: es
  platforms: [vscode, cli]
  categories: [sapui5, sap, ui5, datepicker, input, date]
---

# SAPUI5 DatePicker solo año (yyyy) – instrucciones para el agente

## Propósito
Configurar en una vista SAPUI5 (XMLView) un control `sap.m.DatePicker` que solamente permita introducir el año, 
estableciendo obligatoriamente las propiedades `displayFormat="yyyy"` y `placeholder=" "`.
---

## Reglas / Principios
1. **Control objetivo**: aplicar únicamente sobre controles `sap.m.DatePicker`.
2. **Formato obligatorio**: establecer siempre `displayFormat="yyyy"`.
3. **Placeholder obligatorio**: establecer siempre `placeholder=" "`.
4. **Reemplazo seguro**: si el `sap.m.DatePicker` ya tiene `displayFormat` o `placeholder`, **reemplazarlos** por los valores definidos.
5. **Creación controlada**: si el usuario solicita añadir el control y no existe, generarlo con `id="yearPicker"` salvo que se indique otro id.
6. **No tocar otros controles**: no modificar propiedades de controles que no sean `sap.m.DatePicker`.
7. **Cambios mínimos**: no alterar estructura, namespaces ni otras propiedades existentes; sólo insertar o actualizar `displayFormat` y `placeholder`.
8. **Vista XML**: generar siempre código compatible con XMLView SAPUI5.
---

## Triggers y cuándo usar la skill
- Activar si el prompt contiene frases como:  
  **"DatePicker solo años"**, **"selector de año"**,  
  **"sap.m.DatePicker solo año"**, **"displayFormat yyyy"**,  
  **"DatePicker year only"** o peticiones semánticamente equivalentes.
- Activar cuando el usuario solicite explícitamente un DatePicker que permita introducir únicamente el año.
---

## Plantillas completas (archivos)
Para aplicar el patrón, el agente debe producir el **XML de la vista modificado** siguiendo esta plantilla de control:

```xml
<DatePicker displayFormat="yyyy" placeholder=" " />
```
