# Root Causes — Binding Failures by Model and Binding Type

## JSONModel

| Symptom | Root cause | Fix |
|---|---|---|
| Field shows empty / undefined | Model not set on view or component | `this.getView().setModel(oModel)` in `onInit` |
| Field shows empty / undefined | Named model referenced but model set without name | `setModel(oModel, "view")` — match the name in the binding `{view>/path}` |
| Field shows empty / undefined | Path does not exist in model data | Verify with `oModel.getData()` in console; correct the path |
| Field shows `[object Object]` | Binding points to an object, not a primitive | Bind to a specific property of the object |
| Field shows empty after navigation | Model set in previous onInit not persisted | Use component model or re-set model in `onRouteMatched` |
| List / Table shows no rows | Array path wrong or empty | Verify `oModel.getProperty("/arrayPath")` returns a non-empty array |
| List / Table shows no rows | Aggregation binding uses relative path without context | Use absolute path starting with `/` in `items="{/ArrayPath}"` |
| Expression binding shows `false`/`undefined` | Path inside expression missing `${}` wrapper | Change `{= {/count} > 0}` to `{= ${/count} > 0}` |
| Formatter not called | Formatter function not on controller or not exported | Add the method to the controller or require the formatter module |
| Formatter returns `undefined` | Formatter function does not `return` a value | Add explicit `return` to all code paths |

---

## OData V2

| Symptom | Root cause | Fix |
|---|---|---|
| Field shows empty | Data not yet loaded when binding evaluates | Binding auto-updates when read completes — verify with network tab |
| Field shows empty | Wrong entity path in binding | Check the metadata document; paths are case-sensitive |
| Field shows empty | Model not preloaded; binding evaluates before metadata arrives | Set `preload: true` in manifest.json model config |
| List shows no rows | `items` aggregation bound to wrong entity set path | Use `/EntitySetName` exactly as declared in the metadata |
| List shows no rows | OData request fails (4xx or 5xx) | Check network tab for the request; look for error in `error` callback |
| List shows no rows | Filter applies no results | Verify filter values and operator; log `oBinding.getFilters()` |
| Two-way binding not writing back | `defaultBindingMode` is not `TwoWay` | Set `"defaultBindingMode": "TwoWay"` in model settings |
| `submitChanges()` sends nothing | Control binding not in `TwoWay` mode or path is read-only | Verify binding mode; ensure the property is not marked `Nullable=false` without a value |
| `read()` returns data but binding is empty | Model refresh does not propagate to bound controls | Use `setProperty()` on a JSONModel for view state; for OData, rely on binding refresh |

---

## OData V4

| Symptom | Root cause | Fix |
|---|---|---|
| List shows no rows | Binding is suspended | Call `oBinding.resume()` or `oBinding.refresh()` |
| List shows no rows | Auto-expand disabled and nested data missing | Add `$expand=NavigationProperty` to binding parameters |
| Field shows empty | Context not propagated to control | Verify `oControl.getBindingContext()` is not null |
| Field shows empty | Property not requested in `$select` | Add the property to `$select` in the binding parameters |
| `requestObject()` returns `undefined` | Context not yet resolved async | Await the promise returned by `requestObject()` |
| Patch not sent | `autoExpandSelect` mode; property not in select | Ensure the property is included in the auto-select expansion |
| List not refreshed after create/delete | Binding needs explicit refresh | Call `oListBinding.refresh()` after the operation completes |

---

## Formatter-based bindings

| Symptom | Root cause | Fix |
|---|---|---|
| Formatter never called | Missing leading dot → global function lookup fails | Change `formatter: 'formatX'` to `formatter: '.formatX'` for controller methods |
| Formatter never called | Module not required in `sap.ui.define` | Add the formatter module to the dependency array |
| Formatter receives `undefined` | Binding path resolved to non-existent data | Verify model data and path before adding formatter |
| Formatter called but output is wrong | `parts` array order mismatch in handler arguments | Verify the order of `parts` matches the function parameter order |
| Formatter not called on model change | Binding mode is `OneTime` | Change to `{mode: 'OneWay', ...}` or use default binding mode |

---

## Expression binding

| Symptom | Root cause | Fix |
|---|---|---|
| Syntax error in console | Invalid expression syntax | Check for missing `${}` around model paths |
| Always evaluates to `false` | Comparing strings to numbers | Ensure type consistency: `${/count} > 0` not `${/count} > '0'` |
| Named model not resolved | Missing `${}` wrapper for named model path | Use `${view>/editable}` not `{view>/editable}` inside `{= ... }` |
| Complex logic fails silently | Expression too complex for Expression Binding | Move logic to a formatter or controller method |

---

## Fragment bindings

| Symptom | Root cause | Fix |
|---|---|---|
| All fields empty in fragment | Fragment opened before model is set on view | Set model on view before calling `fragment.open()` |
| Controls not found by ID | Using `this.byId()` with fragment ID without prefix | Use `this.byId("fragmentId--controlId")` or use the `id` parameter in `Fragment.load()` |
| Updates in fragment not reflected in view | Both fragment and view bound to different model instances | Use the same model instance; retrieve it from the view |
| Dialog with form shows empty fields | Dialog bound to a context that is not yet set | Set the binding context on the dialog after creating it |

---

## Binding context (relative paths)

| Symptom | Root cause | Fix |
|---|---|---|
| Relative path in aggregation item resolves to empty | Item bound before `setBindingContext()` | Ensure aggregation binding sets the context automatically via `items="{/Path}"` |
| `{name}` shows empty outside a list | No binding context on the control | Use absolute path `{/name}` or call `control.setBindingContext(oContext)` |
| Navigation property shows empty | Context set on parent but child does not inherit | Use element binding on the child: `oChild.bindElement("/Entity(key)/NavProp")` |
