# Diagnostic Checklist — SAPUI5 Binding Debugger

Use these checklists as structured first-pass diagnostics before proposing any fix.

---

## Checklist A — Property binding shows empty or undefined

### 1. Verify the model exists

```js
// In the browser console (pause on breakpoint in onInit or use UI5 Diagnostics)
var oView = sap.ui.getCore().byId("__xmlview0"); // or find the view ID
console.log(oView.getModel());           // default model
console.log(oView.getModel("view"));     // named model "view"
```

- [ ] Model is **not** `undefined`
- [ ] Model **name** matches the binding prefix  
  (`{view>/path}` requires `setModel(m, "view")`)

### 2. Verify the path

```js
var oModel = oView.getModel();
console.log(oModel.getProperty("/myPath"));      // JSONModel
console.log(oModel.getData());                   // JSONModel — full structure
```

- [ ] Path starts with `/` for absolute bindings
- [ ] Path does not contain typos (case-sensitive)
- [ ] Data at the path is a **primitive** (string, number, boolean), not an object

### 3. Verify the binding declaration in XML

```xml
<!-- Correct examples -->
<Input value="{/name}"/>               <!-- default model, absolute path -->
<Input value="{view>/name}"/>          <!-- named model "view", absolute path -->
<Input value="{name}"/>                <!-- relative — only valid inside aggregation item -->
```

- [ ] Binding syntax uses curly braces `{ }` (not quotes)
- [ ] Named model prefix is correct
- [ ] No typo in property name (`value`, `text`, `enabled`, etc.)

### 4. Verify lifecycle timing

- [ ] Model is set in `onInit` (or earlier, via `manifest.json`)
- [ ] Data is not loaded after binding is evaluated (async issue)
- [ ] For async loads: `setProperty()` is called after data arrives

---

## Checklist B — Aggregation binding (List/Table) shows no rows

### 1. Verify the binding path

```js
var oList = this.getView().byId("myList");
console.log(oList.getBindingInfo("items"));   // sap.m.List / sap.m.Table
console.log(oList.getBinding("items"));        // null means not bound
```

- [ ] `getBinding("items")` is **not** null
- [ ] Binding path is absolute (e.g., `{/EntitySet}` not `{EntitySet}`)
- [ ] Array at the path is **non-empty**

### 2. Verify model data

```js
// JSONModel
console.log(oModel.getProperty("/EntitySet"));   // should be an array

// OData V2
oModel.read("/EntitySet", {
    success: function(oData) { console.log(oData.results); }
});

// OData V4
var oBinding = oList.getBinding("items");
console.log(oBinding.getContexts());   // array of contexts
```

- [ ] Data is an **array**, not an object or `undefined`
- [ ] Array has at least one element

### 3. Verify the template structure in XML

```xml
<!-- sap.m.List — items aggregation is default, tag is still needed -->
<List items="{/Items}">
    <StandardListItem title="{name}"/>
</List>

<!-- sap.m.Table — columns and items -->
<Table items="{/Items}">
    <columns>
        <Column><Text text="Name"/></Column>
    </columns>
    <items>
        <ColumnListItem>
            <cells><Text text="{name}"/></cells>
        </ColumnListItem>
    </items>
</Table>

<!-- sap.ui.table.Table -->
<table:Table rows="{/Items}">
    <table:columns>
        <table:Column>
            <Label text="Name"/>
            <table:template><Text text="{name}"/></table:template>
        </table:Column>
    </table:columns>
</table:Table>
```

- [ ] Template control is inside the correct aggregation tag
- [ ] Inner bindings use **relative** paths (no leading `/`)
- [ ] Column templates are correctly nested

### 4. Verify filters and sorters

- [ ] Active filters do not exclude all results
- [ ] `oBinding.getFilters()` returns expected filter configuration

---

## Checklist C — Formatter not executing

### 1. Verify the formatter reference

```xml
<!-- Controller method — leading dot required -->
<Text text="{path: '/status', formatter: '.formatStatus'}"/>

<!-- External module — full module path -->
<Text text="{path: '/status', formatter: 'myApp.model.formatter.formatStatus'}"/>
```

- [ ] Controller method: binding has leading dot `.formatStatus`
- [ ] External module: module is required in controller's `sap.ui.define` array

### 2. Verify the formatter function

```js
// In controller
formatStatus: function(sValue) {
    if (!sValue) return "";      // guard against undefined
    return sValue === "A" ? "Active" : "Inactive";
}
```

- [ ] Function is defined on the controller object (same level as `onInit`)
- [ ] Function **returns** a value in every code path
- [ ] Function handles `undefined` / `null` input (binding resolves before data arrives)

### 3. Verify parts binding (multiple values)

```xml
<Text text="{parts: [{path: '/first'}, {path: '/last'}], formatter: '.formatFullName'}"/>
```

```js
formatFullName: function(sFirst, sLast) {
    return sFirst + " " + sLast;
}
```

- [ ] Number of `parts` matches number of function parameters
- [ ] Order of parts matches order of parameters

---

## Checklist D — OData binding shows empty

### 1. Check network requests

Open Chrome DevTools → Network tab → filter by "XHR" or the service URL.

- [ ] Request is sent (OData model is active)
- [ ] Response status is `200`
- [ ] Response body contains data (`value` array for V4, `results` array for V2)

### 2. Check for service errors

- [ ] No `401 Unauthorized` (CSRF token or auth issue)
- [ ] No `403 Forbidden` (authorization issue)
- [ ] No `404 Not Found` (wrong service URL or entity set name)
- [ ] No `500 Internal Server Error` (backend issue)

### 3. OData V2 — verify model settings in manifest.json

```json
"models": {
    "": {
        "dataSource": "mainService",
        "preload": true,
        "settings": {
            "defaultBindingMode": "TwoWay"
        }
    }
}
```

- [ ] `preload: true` ensures metadata loads before views render
- [ ] `dataSource` name matches the `dataSources` config in manifest.json
- [ ] Service URL in `dataSources.uri` is correct

### 4. OData V4 — verify binding is not suspended

```js
var oBinding = this.getView().byId("myList").getBinding("items");
console.log(oBinding.isSuspended());   // must be false
```

- [ ] `isSuspended()` returns `false`
- [ ] `$expand` and `$select` are configured if needed

---

## Checklist E — Binding in fragment shows empty

- [ ] The parent view has the model set **before** calling `fragment.open()` or `dialog.open()`
- [ ] Fragment does not require its own model — it inherits from the view
- [ ] If using `Fragment.load({ id: "frag", ... })`, use `this.byId("frag--controlId")` to find controls
- [ ] Dialog binding context is set before opening: `oDialog.setBindingContext(oContext)`
- [ ] The fragment is not using stale `sap.ui.getCore().byId()` references

---

## Quick reference — browser console commands

```js
// Find a view by ID
sap.ui.getCore().byId("__xmlview0")

// Get model from view
sap.ui.getCore().byId("__xmlview0").getModel()
sap.ui.getCore().byId("__xmlview0").getModel("view")

// Get data from JSONModel
sap.ui.getCore().byId("__xmlview0").getModel().getData()

// Get binding context of a control
sap.ui.getCore().byId("controlId").getBindingContext()
sap.ui.getCore().byId("controlId").getBindingContext("view")

// Get binding info of a control property
sap.ui.getCore().byId("controlId").getBindingInfo("text")
sap.ui.getCore().byId("controlId").getBinding("text")

// Get OData V4 list binding
sap.ui.getCore().byId("listId").getBinding("items").getContexts()

// Enable UI5 diagnostics overlay (alternative to DevTools)
// Press Ctrl+Alt+Shift+S in the browser
```
