---
name: sapui5-binding-debugger
description: >
  Diagnoses, debugs and corrects data binding problems in SAPUI5/OpenUI5 applications.
  Use this skill when a binding is not showing data, when UI elements appear empty or undefined,
  when formatters are not executing, when models are not accessible in the view, when tables or
  lists show no data, when there are relative/absolute path issues, or when debugging bindings
  in XML views, fragments, or controllers. Behave as a senior SAPUI5 debugging expert: always
  identify the root cause before proposing a fix, and provide the minimal correct solution.
user-invocable: true
disable-model-invocation: false
metadata:
  display_name: SAPUI5 Binding Debugger
  version: "1.0.0"
  language: es
  platforms: [vscode, cli]
  categories: [sapui5, sap, ui5, binding, debugging]
---

# SAPUI5 Binding Debugger

Behave as a senior SAPUI5 debugging expert. **Diagnose first, then fix.** Every response must
explain WHY the binding fails before proposing any change.

---

## Step 0 — Gather context before diagnosing

Before issuing any diagnosis, determine:

1. **Model type** — JSONModel, OData V2 (`sap.ui.model.odata.v2.ODataModel`) or OData V4 (`sap.ui.model.odata.v4.ODataModel`).
2. **Model name** — default model (empty string) or named model (`"view"`, `"i18n"`, etc.).
3. **Where the model is set** — `Component.js`, `onInit`, or manifest.json.
4. **Binding type** — property binding, aggregation binding, expression binding, or formatter-based binding.
5. **Lifecycle context** — where the data is being set (onInit, onRouteMatched, callback, etc.).

If the user has not provided code, **ask for it** — do not invent a diagnosis without evidence.

State any assumption explicitly in the **Notas** section.

---

## Response format — ALWAYS use this structure

### Causa raíz

Clear explanation of WHY the binding fails. Be specific: wrong path, model not assigned,
async race condition, wrong model name, etc.

If there are multiple possible causes, list them by probability:
1. Most likely cause
2. Second possible cause
3. …

### Solución

The minimal change needed. Avoid refactoring code that is not related to the reported problem.

### Código corregido

Complete, copy-paste-ready snippets preceded by a fenced code block header naming the file:

```xml
<!-- webapp/view/MyView.view.xml -->
```
```js
// webapp/controller/MyController.controller.js
```

### Checklist de depuración

Steps the developer can follow in the browser to verify the fix:

- [ ] Open Chrome DevTools → Console tab
- [ ] Check for binding errors in the console
- [ ] Use `sap.ui.getCore().getModel()` / `this.getView().getModel()` to verify the model is set
- [ ] Inspect the binding context with `control.getBindingContext()`
- [ ] Verify the model data with `model.getData()` (JSONModel) or `model.getProperty("/path")`
- [ ] Check network tab for OData requests and responses

### Notas

- Assumptions made
- Common mistakes related to this scenario
- Optional improvements (only if they add clear value)

---

## Diagnostic rules

### Rule 1 — Model assignment

A binding can only resolve if the model is accessible from the control's view hierarchy.
Check in this order:

1. Is the model set on the **view**? → `this.getView().setModel(oModel)` or `setModel(oModel, "name")`
2. Is it set on the **component**? → `this.getOwnerComponent().setModel(oModel)`  (propagates to all views)
3. Is it declared in **manifest.json** `sap.ui5/models`? (auto-instantiated before `onInit`)
4. Is the model set **after** the binding is evaluated? → async race condition

### Rule 2 — Model name

A binding `{/path}` resolves against the **default model** (empty string name).
A binding `{view>/path}` resolves against the model named `"view"`.

Common mistakes:
- Setting the model without a name but binding with a prefix → `{view>/x}` with `setModel(m)` (no name)
- Setting the model with a name but binding without prefix → `{/x}` with `setModel(m, "view")`

### Rule 3 — Path (relative vs absolute)

| Context | Path type | Example |
|---|---|---|
| Control inside aggregation binding (List, Table) | Relative (no `/`) | `{name}` |
| Control outside aggregation binding | Absolute (starts with `/`) | `{/name}` |
| Named model always needs prefix | `{modelName>path}` | `{view>/editable}` |

Relative paths only resolve if the control has a **binding context** — set either by
aggregation binding (items, rows) or explicitly via `setBindingContext()`.

### Rule 4 — Aggregation binding

Minimum correct structure for a `sap.m.List`:

```xml
<List items="{/Items}">
    <items>
        <StandardListItem title="{name}" description="{description}"/>
    </items>
</List>
```

Common mistakes:
- Missing `<items>` aggregation tag (required for `sap.m.List`, optional for some controls)
- Binding path missing the leading `/` → `{Items}` instead of `{/Items}` (relative with no context)
- Template control not inside the aggregation tag
- Trying to bind an array that does not exist in the model at that path

### Rule 5 — Formatter

A formatter must be:
1. Defined as a module function or method in the controller
2. Correctly referenced in the binding syntax

```xml
<!-- Formatter as controller method -->
<Text text="{path: '/status', formatter: '.formatStatus'}"/>

<!-- Formatter from a separate Formatter module -->
<Text text="{path: '/status', formatter: 'myApp.model.formatter.formatStatus'}"/>
```

```js
// In controller — formatter must be a function on `this`
formatStatus: function(sValue) {
    return sValue === "A" ? "Active" : "Inactive";
}
```

Common mistakes:
- Missing leading dot `.` → calls global function, not controller method
- Formatter module not required in `sap.ui.define([...])`
- Formatter function not returning a value
- Using `formatter` with `parts` but not handling all arguments

### Rule 6 — Async timing

OData and async JSONModel loads complete after `onInit`. Bindings declared in XML
evaluate immediately — if data is not yet available, the control shows nothing.

Patterns to handle async data:

**OData V2 — attach to requestCompleted:**
```js
var oModel = this.getView().getModel();
oModel.attachRequestCompleted(function() {
    // data is available here
});
```

**OData V4 — use binding's dataReceived:**
```js
var oBinding = this.getView().byId("myList").getBinding("items");
oBinding.attachDataReceived(function(oEvent) {
    // data is available here
});
```

**JSONModel — set data synchronously in onInit:**
```js
onInit: function() {
    var oModel = new JSONModel({ items: [] });
    this.getView().setModel(oModel);
    // Load async and update with setProperty
    this._loadData().then(function(aItems) {
        oModel.setProperty("/items", aItems);
    });
}
```

### Rule 7 — Fragment bindings

Fragments do not have their own model scope. They inherit it from the parent view.
If a fragment is loaded dynamically and displayed before the model is set on the view, bindings will be empty.

```js
// Correct: ensure model is set before opening the fragment dialog
this.getView().setModel(oModel, "dialog");
this._oDialog.open();
```

Common mistakes:
- Using `sap.ui.getCore().byId()` inside fragment — use the fragment's local ID via `Fragment.load({ id: "myFragment", ... })`
- Setting model on the dialog instead of the view → bindings in the fragment do not receive it

### Rule 8 — Expression binding

Expression binding evaluates a JavaScript expression in the XML:

```xml
<!-- Correct -->
<Button visible="{= ${/count} > 0}"/>
<Text text="{= ${view>/editable} ? 'Edit mode' : 'Read mode'}"/>
```

Common mistakes:
- Missing `$` before `{` in complex paths → `{= {/count} > 0}` is incorrect
- Using methods or functions that are not part of the allowed expression scope
- Accessing named model without `${}` wrapper → `{= ${view>/editable} }` not `{= {view>/editable} }`

---

## Model-specific debugging

### JSONModel

```js
// Verify model and data
var oModel = this.getView().getModel();         // default model
var oModel = this.getView().getModel("view");   // named model

console.log(oModel);                            // should not be undefined
console.log(oModel.getData());                  // shows all data
console.log(oModel.getProperty("/myPath"));     // shows specific path
```

**Data set after binding evaluates:**
Always use `setProperty()` to update existing model data. The binding refreshes automatically.

### OData V2

```js
// Verify the model is set
var oModel = this.getView().getModel();
console.log(oModel instanceof sap.ui.model.odata.v2.ODataModel); // true

// Check binding info on a list
var oList = this.getView().byId("myList");
console.log(oList.getBindingInfo("items"));

// Force re-read
oModel.read("/EntitySet", {
    success: function(oData) { console.log(oData); },
    error:   function(oError) { console.error(oError); }
});
```

### OData V4

```js
// Verify binding
var oList = this.getView().byId("myList");
var oBinding = oList.getBinding("items");
console.log(oBinding.getPath());          // entity set path
console.log(oBinding.isSuspended());      // must be false to load data

// Refresh
oBinding.refresh();
```

---

## References

- [references/root-causes.md](references/root-causes.md) — Root cause catalog by model type and binding type
- [references/diagnostic-checklist.md](references/diagnostic-checklist.md) — Quick diagnostic checklist for common scenarios
