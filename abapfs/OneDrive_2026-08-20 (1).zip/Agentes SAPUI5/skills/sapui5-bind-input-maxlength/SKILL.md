---
name: sapui5-bind-input-maxlength
description: >
  Configura maxLength en todos los sap.m.Input de una vista SAPUI5,
  bindeándolo a solicitudConfig>/{rutaCampo}/maxLength con formatter .formatMaxLength.
  Usar cuando se solicite establecer, configurar o bindear maxLength según la longitud de una propiedad.
user-invocable: true
disable-model-invocation: false
metadata:
  display_name: SAPUI5 Bind maxLength en sap.m.Input
  version: "1.0.0"
  language: es
  platforms: [vscode, cli]
  categories: [sapui5, sap, ui5, xml, binding, input]
---

# SAPUI5 Bind maxLength en sap.m.Input — instrucciones para el agente

## Propósito
Configurar automáticamente la propiedad `maxLength` en **todos** los controles `sap.m.Input` de una vista SAPUI5 (XMLView), bindeándola al modelo global `solicitudConfig` y aplicando el formatter `.formatMaxLength`.
---

<!--## Agente permitido
**Uso exclusivo de:** `Agente_logica` (agente customizado).  
No aplicar esta skill desde otros agentes.-->
---

## Reglas / Principios
1. **Aplicar a todos los `sap.m.Input`**: localizar cada instancia en la vista y establecer su atributo `maxLength`.
2. **Binding estándar obligatorio**: `maxLength` debe quedar como binding object literal con `path` y `formatter`.
3. **Fuente del dato**: el `path` debe apuntar siempre a `solicitudConfig>/{fieldPath}/maxLength`.
4. **Formatter fijo**: usar siempre `formatter: '.formatMaxLength'`.
5. **Reemplazo seguro**: si el `sap.m.Input` ya tiene `maxLength`, **reemplazarlo** (no mantener valores numéricos ni bindings alternativos).
6. **No tocar otros controles**: no modificar propiedades de controles que no sean `sap.m.Input`.
7. **Cambios mínimos**: no alterar estructura, namespaces, ni otras propiedades; sólo insertar/actualizar `maxLength`.
8. **Normalización de ruta**: si `fieldPath` no empieza por `/`, anteponer `/` antes de componer el binding.
---

## Triggers y cuándo usar la skill
- Activar si el prompt contiene frases como: **"establecer maxLength"**, **"configurar maxLength"**, **"bindear/bindear maxLength"**, **"maxLength en sap.m.Input"**, **"longitud correspondiente"** o peticiones semánticamente equivalentes.
- Activar si el usuario indica explícitamente una ruta de campo (ej. `/solicitante/primerApellido`) y solicita que la longitud se determine por dicha propiedad.
---

## Plantillas completas (archivos)
Para aplicar el patrón, el agente debe producir el **XML de la vista modificado** siguiendo esta plantilla de atributo:

```xml
maxLength="{path: 'solicitudConfig>/{fieldPath}/maxLength', formatter: '.formatMaxLength'}"
```

Y en el fichero formatter.js, el agente debe asegurarse de que exista la función `formatMaxLength` con esta estructura:

```javascript
formatMaxLength: function (iMax) {
    return (iMax !== null && iMax !== undefined) ? Number(iMax) : undefined;
}
```
