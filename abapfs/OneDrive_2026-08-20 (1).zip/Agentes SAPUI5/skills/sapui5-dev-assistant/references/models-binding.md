# Models & Data Binding — Reference

## Table of contents
1. [JSONModel](#1-jsonmodel)
2. [OData V2](#2-odata-v2)
3. [OData V4](#3-odata-v4)
4. [Data binding patterns](#4-data-binding-patterns)
5. [Two-way binding & dirty state](#5-two-way-binding--dirty-state)
6. [Named models](#6-named-models)

---

## 1. JSONModel

### Create & set
```js
// In Component.js or controller onInit
var oViewModel = new JSONModel({
    editable: false,
    busy: false,
    selectedCount: 0,
    items: []
});
this.getView().setModel(oViewModel, "view");
```

### Read / write in controller
```js
// Read
var bEditable = this.getView().getModel("view").getProperty("/editable");

// Write — always use setProperty, never getObject + mutate + refresh
this.getView().getModel("view").setProperty("/editable", true);
this.getView().getModel("view").setProperty("/items", aNewItems);
```

### Bind in XML view
```xml
<Button enabled="{view>/editable}" text="{i18n>save}"/>
<List items="{view>/items}">
    <StandardListItem title="{view>name}" description="{view>description}"/>
</List>
```

---

## 2. OData V2

### Model creation (manifest.json — preferred)
```json
"models": {
    "": {
        "dataSource": "mainService",
        "preload": true,
        "settings": {
            "defaultBindingMode": "TwoWay",
            "useBatch": true,
            "refreshAfterChange": false
        }
    }
}
```

### Read (controller)
```js
var oModel = this.getView().getModel();
oModel.read("/EntitySet", {
    filters: [new Filter("Status", FilterOperator.EQ, "A")],
    sorters: [new Sorter("CreatedAt", true)],
    success: function (oData) {
        this.getView().getModel("view").setProperty("/items", oData.results);
    }.bind(this),
    error: function (oError) {
        MessageBox.error(oError.message);
    }
});
```

### Create
```js
oModel.create("/EntitySet", oPayload, {
    success: function () {
        MessageToast.show(this._getText("createSuccess"));
        oModel.refresh();
    }.bind(this),
    error: function (oError) {
        MessageBox.error(oError.message);
    }
});
```

### Update
```js
var sPath = oModel.createKey("/EntitySet", { Id: sId });
oModel.update(sPath, oPayload, {
    success: function () { /* ... */ },
    error: function (oError) { /* ... */ }
});
```

### Delete
```js
var sPath = oModel.createKey("/EntitySet", { Id: sId });
oModel.remove(sPath, {
    success: function () { /* ... */ },
    error: function (oError) { /* ... */ }
});
```

### Batch group
```js
oModel.setDeferredGroups(["batchGroup"]);
oModel.create("/EntityA", oPayloadA, { groupId: "batchGroup" });
oModel.create("/EntityB", oPayloadB, { groupId: "batchGroup" });
oModel.submitChanges({ groupId: "batchGroup" });
```

---

## 3. OData V4

### List binding (read-only table)
```xml
<Table items="{
    path: '/EntitySet',
    parameters: {
        $select: 'Id,Name,Status',
        $expand: 'Category',
        $$updateGroupId: 'batch1'
    }
}">
    <columns><Column><Text text="Name"/></Column></columns>
    <items>
        <ColumnListItem>
            <cells><Text text="{Name}"/></cells>
        </ColumnListItem>
    </items>
</Table>
```

### Context binding (detail view)
```js
onRouteMatched: function (oEvent) {
    var sId = oEvent.getParameter("arguments").id;
    this.getView().bindElement({
        path: "/EntitySet(" + sId + ")",
        parameters: { $expand: "Category" }
    });
}
```

### Create (V4)
```js
var oListBinding = this.getView().byId("myTable").getBinding("items");
var oContext = oListBinding.create({
    Name: "New Item",
    Status: "A"
});
oContext.created().then(function () {
    MessageToast.show("Created");
}).catch(function (oError) {
    MessageBox.error(oError.message);
});
```

### Submit changes (V4)
```js
this.getView().getModel().submitBatch("batch1").then(function () {
    MessageToast.show("Saved");
}).catch(function (oError) {
    MessageBox.error(oError.message);
});
```

### Key differences V2 vs V4

| Aspect | OData V2 | OData V4 |
|---|---|---|
| Model class | `sap.ui.model.odata.v2.ODataModel` | `sap.ui.model.odata.v4.ODataModel` |
| Read API | `oModel.read()` | List/context binding (declarative or `requestObject`) |
| Create | `oModel.create()` | `oListBinding.create()` |
| Batch | `setDeferredGroups` + `submitChanges` | `$$groupId` + `submitBatch` |
| Draft | Manual | Built-in via `$$patchWithoutOptimisticLocking` |
| Refresh | `oModel.refresh()` | `oBinding.refresh()` |

---

## 4. Data binding patterns

### Absolute vs. relative paths
```xml
<!-- Absolute: starts with / — resolves from model root -->
<Text text="{/userName}"/>

<!-- Relative: resolves from binding context (e.g., inside a List items template) -->
<StandardListItem title="{name}" description="{email}"/>
```

Common mistake: using a relative path without a binding context → control renders empty.

### Composite binding
```xml
<Text text="{parts: [{path: '/firstName'}, {path: '/lastName'}],
             formatter: '.formatFullName'}"/>
```

### Property binding with type
```xml
<Input value="{
    path: '/amount',
    type: 'sap.ui.model.type.Float',
    formatOptions: { decimals: 2 },
    constraints: { minimum: 0 }
}"/>
```

### One-time binding (static data)
```xml
<Text text="{= 'prefix_' + ${/code} }"/>
<!-- Or use bindingMode -->
<Text text="{path: '/label', mode: 'OneTime'}"/>
```

---

## 5. Two-way binding & dirty state

Enable two-way globally in model settings or per-binding:
```json
"settings": { "defaultBindingMode": "TwoWay" }
```

Track dirty state with a view model flag:
```js
onChangeField: function () {
    this.getView().getModel("view").setProperty("/isDirty", true);
},

onPressSave: function () {
    if (!this.getView().getModel("view").getProperty("/isDirty")) { return; }
    // submit changes...
    this.getView().getModel("view").setProperty("/isDirty", false);
}
```

---

## 6. Named models

Use named models to separate concerns. Convention:

| Name | Purpose |
|---|---|
| `""` (default) | OData service model |
| `"view"` | UI state (busy, editable, selectedItems…) |
| `"i18n"` | Resource bundle |
| `"device"` | `sap.ui.Device` properties |

Never use the default OData model to store local UI state — always use a separate `"view"` JSONModel.

```js
// In onInit — set up a dedicated view model
var oViewModel = new JSONModel({ busy: false, editable: false });
this.getView().setModel(oViewModel, "view");

// Usage in XML
// <BusyIndicator visible="{view>/busy}"/>
```
