# manifest.json & Component.js — Reference

## Table of contents
1. [manifest.json full structure](#1-manifestjson-full-structure)
2. [dataSources](#2-datasources)
3. [Models in manifest](#3-models-in-manifest)
4. [sap.ui5 key settings](#4-sapui5-key-settings)
5. [Component.js](#5-componentjs)
6. [Device model](#6-device-model)

---

## 1. manifest.json full structure

```json
{
    "_version": "1.65.0",
    "sap.app": {
        "id": "myApp",
        "type": "application",
        "i18n": "i18n/i18n.properties",
        "applicationVersion": { "version": "1.0.0" },
        "title": "{{appTitle}}",
        "description": "{{appDescription}}",
        "dataSources": {
            "mainService": {
                "uri": "/sap/opu/odata/sap/MY_SERVICE/",
                "type": "OData",
                "settings": { "odataVersion": "2.0" }
            }
        }
    },
    "sap.ui": {
        "technology": "UI5",
        "icons": { "icon": "" },
        "deviceTypes": { "desktop": true, "tablet": true, "phone": true }
    },
    "sap.ui5": {
        "flexEnabled": false,
        "dependencies": {
            "minUI5Version": "1.108.0",
            "libs": {
                "sap.m": {},
                "sap.ui.core": {},
                "sap.f": { "lazy": true }
            }
        },
        "contentDensities": {
            "compact": true,
            "cozy": true
        },
        "models": {
            "i18n": {
                "type": "sap.ui.model.resource.ResourceModel",
                "settings": { "bundleName": "myApp.i18n.i18n" }
            },
            "": {
                "dataSource": "mainService",
                "preload": true,
                "settings": {
                    "defaultBindingMode": "TwoWay",
                    "useBatch": true,
                    "refreshAfterChange": false
                }
            }
        },
        "rootView": {
            "viewName": "myApp.view.App",
            "type": "XML",
            "async": true,
            "id": "app"
        },
        "routing": { }
    }
}
```

**Critical settings:**
- `flexEnabled: false` — disable UI Adaptation to avoid unnecessary ID generation.
- `rootView.async: true` — mandatory; prevents blocking the main thread.
- `routing.config.async: true` — same reason, required for lazy view loading.
- `refreshAfterChange: false` (OData V2) — prevent full model refresh after every CRUD; use targeted `setProperty` or selective refresh instead.

---

## 2. dataSources

### OData V2
```json
"mainService": {
    "uri": "/sap/opu/odata/sap/MY_SRV/",
    "type": "OData",
    "settings": { "odataVersion": "2.0" }
}
```

### OData V4
```json
"mainService": {
    "uri": "/sap/opu/odata4/sap/my_srv/default/sap/my_srv/0001/",
    "type": "OData",
    "settings": { "odataVersion": "4.0" }
}
```

### Local mock (development)
```json
"mainService": {
    "uri": "/localService/mockdata/",
    "type": "OData",
    "settings": { "odataVersion": "2.0", "localUri": "localService/metadata.xml" }
}
```

---

## 3. Models in manifest

### OData (default model)
```json
"": {
    "dataSource": "mainService",
    "preload": true
}
```

### ResourceModel (i18n)
```json
"i18n": {
    "type": "sap.ui.model.resource.ResourceModel",
    "settings": {
        "bundleName": "myApp.i18n.i18n",
        "supportedLocales": ["", "en", "es"],
        "fallbackLocale": "en"
    }
}
```

### JSONModel (device)
```json
"device": {
    "type": "sap.ui.model.json.JSONModel",
    "uri": "model/device.json",
    "preload": true
}
```

---

## 4. sap.ui5 key settings

| Setting | Recommended value | Reason |
|---|---|---|
| `flexEnabled` | `false` | Avoids generating unnecessary IDs for every control |
| `rootView.async` | `true` | Non-blocking app bootstrap |
| `routing.config.async` | `true` | Non-blocking view loading |
| `contentDensities.compact` | `true` | Required for SAP Fiori desktop support |
| `minUI5Version` | `"1.108.0"` or higher | Use a supported LTS version |

---

## 5. Component.js

```js
sap.ui.define([
    "sap/ui/core/UIComponent",
    "sap/ui/Device",
    "sap/ui/model/json/JSONModel"
], function (UIComponent, Device, JSONModel) {
    "use strict";

    return UIComponent.extend("myApp.Component", {
        metadata: {
            manifest: "json"
        },

        init: function () {
            // Call super FIRST
            UIComponent.prototype.init.apply(this, arguments);

            // Set device model
            this._setDeviceModel();

            // Initialize router LAST (after all models are ready)
            this.getRouter().initialize();
        },

        _setDeviceModel: function () {
            var oDeviceModel = new JSONModel(Device);
            oDeviceModel.setDefaultBindingMode("OneWay");
            this.setModel(oDeviceModel, "device");
        }
    });
});
```

**Rules:**
- Always call `UIComponent.prototype.init.apply(this, arguments)` first.
- Always call `this.getRouter().initialize()` last, after all models are registered.
- Do not add business logic to `Component.js` — only app-level setup (models, router).

---

## 6. Device model

Expose `sap.ui.Device` as a named model to use in XML for responsive adaption:

```xml
<!-- Show only on desktop -->
<Button visible="{device>/system/desktop}" text="{i18n>exportExcel}"/>

<!-- Adapt layout to screen size -->
<FlexBox direction="{= ${device>/system/phone} ? 'Column' : 'Row' }">
```

In Component.js (`_setDeviceModel` as shown above):
```js
var oDeviceModel = new JSONModel(Device);
oDeviceModel.setDefaultBindingMode("OneWay");
this.setModel(oDeviceModel, "device");
```

Properties available: `device>/system/phone`, `device>/system/tablet`, `device>/system/desktop`, `device>/support/touch`.
