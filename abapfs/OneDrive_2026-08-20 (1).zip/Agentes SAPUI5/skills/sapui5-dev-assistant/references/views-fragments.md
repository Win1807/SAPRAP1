# XML Views & Fragments — Reference

## Table of contents
1. [XML View anatomy](#1-xml-view-anatomy)
2. [Control namespaces](#2-control-namespaces)
3. [Fragments — Dialog](#3-fragments--dialog)
4. [Fragments — Popover & ActionSheet](#4-fragments--popover--actionsheet)
5. [Formatters](#5-formatters)
6. [Expression Binding](#6-expression-binding)
7. [Custom Controls](#7-custom-controls)

---

## 1. XML View anatomy

```xml
<mvc:View
    controllerName="myApp.controller.Main"
    xmlns:mvc="sap.ui.core.mvc"
    xmlns="sap.m"
    xmlns:core="sap.ui.core"
    displayBlock="true">
    <Page title="{i18n>pageTitle}" showNavButton="true" navButtonPress=".onNavBack">
        <content>
            <!-- controls here -->
        </content>
        <footer>
            <OverflowToolbar>
                <ToolbarSpacer/>
                <Button text="{i18n>save}" type="Emphasized" press=".onPressSave"/>
            </OverflowToolbar>
        </footer>
    </Page>
</mvc:View>
```

**Rules:**
- `<mvc:View>` is the only element formatted with one property per line.
- All other controls: one line per control, all properties inline.
- Never use global `id` attributes — identify controls by position via `getAggregation()` in `onInit`.
- All visible text must reference `{i18n>key}`.

---

## 2. Control namespaces

| Prefix | Namespace | Typical use |
|---|---|---|
| (default) | `sap.m` | Mobile-first controls (Page, Button, Input, Table…) |
| `f` | `sap.f` | Flexible Column Layout, DynamicPage |
| `uxap` | `sap.uxap` | ObjectPage, ObjectPageSection |
| `table` | `sap.ui.table` | Desktop Grid Table |
| `core` | `sap.ui.core` | Icon, CustomData, Fragment |
| `layout` | `sap.ui.layout` | Form, GridLayout, HBox, VBox |

Declare only the namespaces actually used in the view.

---

## 3. Fragments — Dialog

### Fragment file (webapp/fragment/ConfirmDialog.fragment.xml)
```xml
<core:FragmentDefinition xmlns="sap.m" xmlns:core="sap.ui.core">
    <Dialog title="{i18n>confirmTitle}" type="Message">
        <content>
            <Text text="{i18n>confirmMessage}"/>
        </content>
        <buttons>
            <Button text="{i18n>confirm}" type="Emphasized" press=".onPressConfirm"/>
            <Button text="{i18n>cancel}" press=".onPressCancel"/>
        </buttons>
    </Dialog>
</core:FragmentDefinition>
```

### Controller — load once, reuse
```js
onPressOpenDialog: function () {
    if (!this._oConfirmDialog) {
        this._oConfirmDialog = Fragment.load({
            id: this.getView().getId(),
            name: "myApp.fragment.ConfirmDialog",
            controller: this
        }).then(function (oDialog) {
            this.getView().addDependent(oDialog);
            this._oConfirmDialog = oDialog;
            oDialog.open();
        }.bind(this));
    } else {
        this._oConfirmDialog.open();
    }
},

onPressCancel: function () {
    this._oConfirmDialog.close();
}
```

**Key rules:**
- Always `addDependent` so the dialog is destroyed with the view.
- Guard with `if (!this._oDialog)` to avoid loading the fragment multiple times.
- Pass `id: this.getView().getId()` to namespace fragment control IDs and avoid clashes.

---

## 4. Fragments — Popover & ActionSheet

### Popover
```js
onPressOpenPopover: function (oEvent) {
    var oSource = oEvent.getSource();
    if (!this._oPopover) {
        Fragment.load({
            name: "myApp.fragment.FilterPopover",
            controller: this
        }).then(function (oPopover) {
            this.getView().addDependent(oPopover);
            this._oPopover = oPopover;
            oPopover.openBy(oSource);
        }.bind(this));
    } else {
        this._oPopover.openBy(oSource);
    }
}
```

### ActionSheet
```js
onPressMore: function (oEvent) {
    var oButton = oEvent.getSource();
    if (!this._oActionSheet) {
        Fragment.load({
            name: "myApp.fragment.MoreActions",
            controller: this
        }).then(function (oSheet) {
            this.getView().addDependent(oSheet);
            this._oActionSheet = oSheet;
            oSheet.openBy(oButton);
        }.bind(this));
    } else {
        this._oActionSheet.openBy(oButton);
    }
}
```

---

## 5. Formatters

### File: webapp/model/formatter.js
```js
sap.ui.define([], function () {
    "use strict";
    return {
        /**
         * @description Formats a status code into a sap.ui.core.ValueState string
         * @param {string} sStatus
         * @returns {string}
         */
        statusToState: function (sStatus) {
            var mMap = { "A": "Success", "W": "Warning", "E": "Error" };
            return mMap[sStatus] || "None";
        },

        /**
         * @description Formats a boolean to visible/hidden text
         * @param {boolean} bValue
         * @returns {string}
         */
        boolToText: function (bValue) {
            return bValue ? "Yes" : "No";
        }
    };
});
```

### Usage in XML view
```xml
<mvc:View xmlns:mvc="sap.ui.core.mvc" xmlns="sap.m"
    core:require="{ formatter: 'myApp/model/formatter' }">
    <ObjectStatus state="{= formatter.statusToState(${/status}) }"  text="{/statusText}"/>
</mvc:View>
```

Or with the `formatter` property on a binding:
```xml
<Text text="{path: '/price', formatter: '.formatter.formatCurrency'}"/>
```
(Requires `this.formatter = formatter;` in controller `onInit`.)

---

## 6. Expression Binding

Use for **trivial conditions only** — comparison, ternary, simple boolean logic.

```xml
<!-- Visibility based on model value -->
<Button visible="{= ${/editable} === true }"/>

<!-- Ternary for state -->
<ObjectStatus state="{= ${/amount} > 0 ? 'Success' : 'Error' }"/>

<!-- String concatenation -->
<Title text="{= ${i18n>hello} + ' ' + ${/userName} }"/>
```

**Do NOT** use expression binding for:
- Multi-condition logic (use a formatter instead).
- Any computation that needs to be unit-tested.
- Operations that call functions or require imports.

---

## 7. Custom Controls

Extend `sap.ui.core.Control` only when built-in controls cannot cover the requirement. Prefer composition with `sap.ui.core.Fragment` first.

```js
// webapp/control/StatusBadge.js
sap.ui.define([
    "sap/ui/core/Control"
], function (Control) {
    "use strict";
    return Control.extend("myApp.control.StatusBadge", {
        metadata: {
            properties: {
                text: { type: "string", defaultValue: "" },
                state: { type: "string", defaultValue: "None" }
            }
        },
        renderer: function (oRm, oControl) {
            oRm.openStart("span");
            oRm.class("myStatusBadge");
            oRm.class("myStatusBadge--" + oControl.getState().toLowerCase());
            oRm.openEnd();
            oRm.text(oControl.getText());
            oRm.close("span");
        }
    });
});
```
