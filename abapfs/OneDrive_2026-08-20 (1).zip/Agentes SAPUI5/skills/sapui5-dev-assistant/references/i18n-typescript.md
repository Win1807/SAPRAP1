# i18n & TypeScript — Reference

## Table of contents
1. [i18n — file structure](#1-i18n--file-structure)
2. [Key naming conventions](#2-key-naming-conventions)
3. [Using i18n in views](#3-using-i18n-in-views)
4. [Using i18n in controllers](#4-using-i18n-in-controllers)
5. [Pluralisation & parameters](#5-pluralisation--parameters)
6. [TypeScript setup](#6-typescript-setup)
7. [Typed controller base](#7-typed-controller-base)
8. [Common TypeScript patterns](#8-common-typescript-patterns)

---

## 1. i18n — file structure

```
webapp/i18n/
├── i18n.properties          ← default (fallback) language
├── i18n_en.properties       ← English
├── i18n_es.properties       ← Spanish
└── i18n_de.properties       ← German
```

Register in `manifest.json`:
```json
"i18n": {
    "type": "sap.ui.model.resource.ResourceModel",
    "settings": {
        "bundleName": "myApp.i18n.i18n",
        "supportedLocales": ["", "en", "es", "de"],
        "fallbackLocale": "en"
    }
}
```

---

## 2. Key naming conventions

Pattern: `VIEW_SECTION_ELEMENT` — all uppercase with underscores.

```properties
# App-level
APP_TITLE=My Application
APP_LOADING=Loading...

# List view
LIST_TITLE=Requests
LIST_SEARCHFIELD_PLACEHOLDER=Search by name
LIST_TABLE_COL_ID=ID
LIST_TABLE_COL_NAME=Name
LIST_TABLE_COL_STATUS=Status

# Detail view
DETAIL_TITLE=Request Detail
DETAIL_FIELD_CUSTOMER=Customer
DETAIL_FIELD_AMOUNT=Amount
DETAIL_BTN_SAVE=Save
DETAIL_BTN_CANCEL=Cancel
DETAIL_BTN_EDIT=Edit
DETAIL_MSG_SAVE_SUCCESS=Record saved successfully
DETAIL_MSG_SAVE_ERROR=An error occurred while saving

# Validation
VALIDATION_MANDATORY_FIELD={0} is required
VALIDATION_INVALID_FORMAT={0} has an invalid format
```

---

## 3. Using i18n in views

Simple text:
```xml
<Button text="{i18n>DETAIL_BTN_SAVE}" type="Emphasized" press=".onPressSave"/>
<Title text="{i18n>LIST_TITLE}"/>
```

With expression (combine i18n key with model value):
```xml
<Title text="{= ${i18n>DETAIL_TITLE} + ' — ' + ${/referenceId} }"/>
```

Manifest app title (uses `{{}}` double braces — resolved at app bootstrap):
```json
"sap.app": {
    "title": "{{APP_TITLE}}"
}
```

---

## 4. Using i18n in controllers

### Shorthand helper (put in App.controller.js base)
```js
/**
 * @description Returns a translated text from the i18n resource bundle
 * @memberof App
 * @method _getText
 * @param {string} sKey
 * @param {Array} [aArgs]
 * @returns {string}
 * @public
 */
_getText: function (sKey, aArgs) {
    return this.getOwnerComponent().getModel("i18n")
        .getResourceBundle()
        .getText(sKey, aArgs);
},
```

### Usage in child controllers
```js
MessageToast.show(this._getText("DETAIL_MSG_SAVE_SUCCESS"));
MessageBox.error(this._getText("DETAIL_MSG_SAVE_ERROR"));

// With parameter substitution
var sMsg = this._getText("VALIDATION_MANDATORY_FIELD", ["Amount"]);
```

---

## 5. Pluralisation & parameters

### Positional parameters (`{0}`, `{1}`)
```properties
LIST_SELECTED_COUNT={0} items selected
DETAIL_WELCOME=Hello, {0}! You have {1} pending tasks.
```

```js
this._getText("LIST_SELECTED_COUNT", [iCount]);
this._getText("DETAIL_WELCOME", [sName, iPending]);
```

### Plural form (requires CLDR plural rules — available in UI5 ≥ 1.77)
```properties
LIST_ITEMS_FOUND={0} item found|{0} items found
```
```js
this.getOwnerComponent().getModel("i18n")
    .getResourceBundle()
    .getText("LIST_ITEMS_FOUND", [iCount], true); // true = use plural
```

---

## 6. TypeScript setup

### Required packages
```bash
npm install --save-dev typescript @sapui5/types @ui5/ts-interface-generator
```

### tsconfig.json
```json
{
    "compilerOptions": {
        "target": "ES2020",
        "module": "ES2020",
        "moduleResolution": "bundler",
        "strict": true,
        "noUnusedLocals": true,
        "noUnusedParameters": true,
        "skipLibCheck": true,
        "esModuleInterop": true,
        "allowSyntheticDefaultImports": true,
        "outDir": "./webapp",
        "rootDir": "./src",
        "paths": {
            "myApp/*": ["./src/*"]
        }
    },
    "include": ["src"]
}
```

### ui5.yaml (TypeScript build)
```yaml
builder:
  resources:
    excludes:
      - "/test/**"
  customTasks:
    - name: ui5-tooling-transpile-task
      afterTask: replaceVersion
```

---

## 7. Typed controller base

```typescript
// src/controller/App.controller.ts
import Controller from "sap/ui/core/mvc/Controller";
import ResourceBundle from "sap/base/i18n/ResourceBundle";
import ResourceModel from "sap/ui/model/resource/ResourceModel";
import Router from "sap/ui/core/routing/Router";
import UIComponent from "sap/ui/core/UIComponent";

export default class AppController extends Controller {

    protected _getText(sKey: string, aArgs?: string[]): string {
        const oModel = (this.getOwnerComponent() as UIComponent)
            .getModel("i18n") as ResourceModel;
        const oBundle = oModel.getResourceBundle() as ResourceBundle;
        return oBundle.getText(sKey, aArgs) ?? sKey;
    }

    protected _getRouter(): Router {
        return (this.getOwnerComponent() as UIComponent).getRouter();
    }

    public onNavBack(): void {
        window.history.go(-1);
    }
}
```

---

## 8. Common TypeScript patterns

### Typed onInit + view model
```typescript
import AppController from "./App.controller";
import JSONModel from "sap/ui/model/json/JSONModel";

interface IViewModel {
    busy: boolean;
    editable: boolean;
    title: string;
}

export default class DetailController extends AppController {

    private _oViewModel!: JSONModel;

    public onInit(): void {
        super.onInit?.();

        this._oViewModel = new JSONModel({
            busy: false,
            editable: false,
            title: ""
        } as IViewModel);

        this.getView()!.setModel(this._oViewModel, "view");

        this._getRouter()
            .getRoute("detail")!
            .attachPatternMatched(this._onRouteMatched, this);
    }

    private _onRouteMatched(oEvent: Event): void {
        const sId = (oEvent as any).getParameter("arguments").objectId as string;
        this._loadData(decodeURIComponent(sId));
    }

    private _loadData(sId: string): void {
        this._oViewModel.setProperty("/busy", true);
        // ... load data ...
    }
}
```

### Cast model to typed interface
```typescript
const oData = this.getView()!.getModel() as ODataModel;
const oView = this.getView()!.getModel("view") as JSONModel;
const iCount = oView.getProperty("/selectedCount") as number;
```

### Accessing controls (avoid byId with string everywhere)
```typescript
// In onInit — store typed reference
private _oTable!: Table;

public onInit(): void {
    this._oTable = this.getView()!.getContent()[0] as Table;
}
```
