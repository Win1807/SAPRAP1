# Debugging & Error Diagnosis — Reference

## Table of contents
1. [Broken bindings — diagnostic checklist](#1-broken-bindings--diagnostic-checklist)
2. [Common runtime errors](#2-common-runtime-errors)
3. [OData errors](#3-odata-errors)
4. [Routing issues](#4-routing-issues)
5. [Fragment issues](#5-fragment-issues)
6. [Performance diagnostics](#6-performance-diagnostics)
7. [Useful console commands](#7-useful-console-commands)

---

## 1. Broken bindings — diagnostic checklist

When a control renders empty or does not update, check in this order:

1. **Is the model set?**
   ```js
   console.log(this.getView().getModel());          // default model
   console.log(this.getView().getModel("view"));    // named model
   ```
   If `undefined` → model was not registered on the view or its parent.

2. **Is the path absolute or relative?**
   - Absolute: starts with `/` → resolves from model root.
   - Relative: no leading `/` → resolves from the current binding context.
   - Inside a list template: relative is correct. Outside: must be absolute.

3. **Does the binding context exist?**
   ```js
   console.log(this.getView().getBindingContext());
   ```
   If `null` → `bindElement` was not called or the OData path returned no data.

4. **Has the data loaded yet?**
   - For OData: check the **Network tab** in DevTools. If the request is pending, the control is empty until it resolves.
   - For late-loaded data: update the model with `setProperty` after the response arrives.

5. **Is the property name correct?**
   - OData property names are case-sensitive. Verify against the `$metadata` document.
   - For JSONModel: check the exact key name in the model data.

6. **Is Expression Binding syntax valid?**
   - Must use `{= ... }` (space after `=`).
   - Inner bindings must use `${path}` syntax.
   - Test with `sap.ui.getCore().applyChanges()` to force re-render.

---

## 2. Common runtime errors

### "Cannot read properties of undefined (reading 'getModel')"
The view is not yet rendered when the code runs. Ensure model access happens inside `onInit` or later, not during module define phase.

### "Uncaught Error: failed to load 'myApp/controller/Detail.controller.js'"
Module path is wrong or the file name has incorrect casing (case-sensitive on Linux servers). Check: capitalization, `/` vs `.` in `sap.ui.define`, and folder structure.

### "Model with name '' not found"
The default OData model is not set on the component. Check `manifest.json` `"models"` section and that `dataSource` name matches a `dataSources` entry.

### "TypeError: this.byId(...) is not a function"
The function is called before `onInit` or the context (`this`) is lost. Always bind callbacks: `.bind(this)` or use arrow functions.

### "Assertion failed: 'oContainer' must not be null"
A view/fragment tried to insert itself into a control that doesn't exist yet. Check the `controlId` in `manifest.json` routing config matches the actual control ID in `App.view.xml`.

---

## 3. OData errors

### 404 — Service not found
- Check the service URI in `manifest.json` `dataSources`.
- Ensure the backend destination/proxy is configured in `xs-app.json` or `ui5.yaml`.

### 401/403 — Unauthorized
- CSRF token not sent: for OData V2, the model fetches the token automatically on the first modifying request. If it fails, check `useCsrfTokens: true` (default).
- For local mock server: not applicable — skip token.

### 400 — Bad request / missing field
- Log `oError.responseText` in the error callback for the detailed OData error message.
  ```js
  error: function (oError) {
      var sMessage = oError.responseText || oError.message;
      MessageBox.error(sMessage);
  }
  ```

### Metadata load failed
- The OData model bootstraps by fetching `$metadata`. If this fails, all bindings fail silently.
- Check **Network tab** for the `$metadata` request and inspect the response.

---

## 4. Routing issues

### View not displayed when navigating
- Verify the route `pattern` in `manifest.json` exactly matches the hash. Test by pasting the hash manually in the URL.
- Check `controlId` and `controlAggregation` in `targets` — they must match the container in `App.view.xml`.
- Confirm `this.getRouter().initialize()` is called in `Component.js`.

### `onRouteMatched` never fires
- You attached to the wrong event. Use `attachPatternMatched` on the specific route, not `attachMatched` on the router (which fires for every route).
- Verify the route name in `getRoute("name")` matches the `manifest.json` route name exactly.

### Parameters are `undefined`
- Ensure parameter names in `pattern` match the keys used in `getParameter("arguments")`.
  - Pattern: `"detail/{objectId}"` → `oEvent.getParameter("arguments").objectId`
- Decode the parameter if you encoded it during navTo: `decodeURIComponent(...)`.

---

## 5. Fragment issues

### Dialog opens multiple times (stacked)
- Fragment is loaded more than once. Add the `if (!this._oDialog)` guard.

### Controls inside fragment not found via `this.byId()`
- Fragment controls use the fragment ID prefix. When you load with `id: this.getView().getId()`, use `this.byId("controlId")` (same as view).
- Without ID prefix: use `Fragment.byId(sFragmentId, "controlId")`.

### Fragment shows stale data
- The fragment DOM is reused but the model data behind it changed. Either:
  - Update the model via `setProperty`, **or**
  - Call `oDialog.getModel().refresh()` on the local model, **or**
  - Destroy the fragment on close and recreate on next open (only for non-frequent dialogs).

---

## 6. Performance diagnostics

### Too many re-renders
- Avoid calling `oModel.refresh()` to update a single property — use `setProperty`.
- In OData V2: set `refreshAfterChange: false` in model settings; refresh only the affected entity.

### Slow initial load
- Enable async view loading (`rootView.async: true` and `routing.config.async: true`).
- Use `lazy: true` on non-critical library dependencies in `manifest.json`.
- Defer heavy data loads to `onRouteMatched` instead of `onInit`.

### Memory leaks
- Fragments not destroyed on view destroy. Use `addDependent(oFragment)` so they are cleaned up automatically.
- Detach event listeners registered on external objects (Router, Event Bus) in `onExit`:
  ```js
  onExit: function () {
      this.getOwnerComponent().getRouter()
          .getRoute("detail")
          .detachPatternMatched(this._onRouteMatched, this);
  }
  ```

---

## 7. Useful console commands

Open the UI5 Diagnostics tool (in-browser):
```
Ctrl+Alt+Shift+S   →  opens sap.ui.core.support.Support dialog
Ctrl+Alt+Shift+P   →  opens VersionInfo popup
```

Inspect a control from the console:
```js
// Get control by ID
sap.ui.getCore().byId("myControlId")

// Get all rendered controls
sap.ui.getCore().getUIArea("content").getContent()

// Inspect model bindings of a specific control
var oCtrl = sap.ui.getCore().byId("myInput");
oCtrl.getBindingInfo("value");
oCtrl.getBinding("value").getPath();
```

Check current URL hash:
```js
sap.ui.getCore().getComponent("componentId").getRouter().oHashChanger.getHash()
```
