# Routing & Navigation — Reference

## Table of contents
1. [manifest.json routing config](#1-manifestjson-routing-config)
2. [Router initialization in Component.js](#2-router-initialization-in-componentjs)
3. [Navigate to a route (navTo)](#3-navigate-to-a-route-navto)
4. [Handle route match in target controller](#4-handle-route-match-in-target-controller)
5. [Back navigation](#5-back-navigation)
6. [Nested routes & FCL (Flexible Column Layout)](#6-nested-routes--fcl-flexible-column-layout)
7. [Deep links & URL parameters](#7-deep-links--url-parameters)

---

## 1. manifest.json routing config

```json
"sap.ui5": {
    "routing": {
        "config": {
            "routerClass": "sap.m.routing.Router",
            "type": "JSON",
            "viewType": "XML",
            "path": "myApp.view",
            "controlId": "app",
            "controlAggregation": "pages",
            "bypassed": { "target": "notFound" },
            "async": true
        },
        "routes": [
            {
                "name": "list",
                "pattern": "",
                "target": ["list"]
            },
            {
                "name": "detail",
                "pattern": "detail/{objectId}",
                "target": ["list", "detail"]
            },
            {
                "name": "create",
                "pattern": "create",
                "target": ["list", "create"]
            }
        ],
        "targets": {
            "list": {
                "id": "list",
                "name": "List",
                "level": 1
            },
            "detail": {
                "id": "detail",
                "name": "Detail",
                "level": 2
            },
            "create": {
                "id": "create",
                "name": "Create",
                "level": 2
            },
            "notFound": {
                "id": "notFound",
                "name": "NotFound"
            }
        }
    }
}
```

**Key settings:**
- `async: true` — mandatory for performance; enables non-blocking view loading.
- `level` — controls back-navigation animation direction (higher = goes forward).
- Multiple targets in a route — used with `SplitApp` or `FlexibleColumnLayout`.

---

## 2. Router initialization in Component.js

```js
// Component.js — router is initialized automatically via manifest, but you must call:
init: function () {
    UIComponent.prototype.init.apply(this, arguments);
    // Initialize router AFTER super.init so models are ready
    this.getRouter().initialize();
}
```

---

## 3. Navigate to a route (navTo)

### Navigate without parameters
```js
this.getOwnerComponent().getRouter().navTo("list");
```

### Navigate with a mandatory path parameter
```js
this.getOwnerComponent().getRouter().navTo("detail", {
    objectId: encodeURIComponent(sId)
});
```

### Navigate replacing current history entry (no back button)
```js
this.getOwnerComponent().getRouter().navTo("list", {}, true);
```

**Important:** Always `encodeURIComponent` string parameters that may contain special characters (e.g., OData keys with parentheses).

---

## 4. Handle route match in target controller

```js
onInit: function () {
    this.getOwnerComponent().getRouter()
        .getRoute("detail")
        .attachPatternMatched(this._onRouteMatched, this);
},

_onRouteMatched: function (oEvent) {
    var sObjectId = decodeURIComponent(oEvent.getParameter("arguments").objectId);
    this._loadData(sObjectId);
},

_loadData: function (sId) {
    var oModel = this.getView().getModel();
    var sPath = oModel.createKey("/EntitySet", { Id: sId });
    this.getView().bindElement({ path: sPath });
}
```

**Use `attachPatternMatched`** (not `attachMatched`) — `attachPatternMatched` fires only when this specific route matches; `attachMatched` fires for all routes including parent routes.

---

## 5. Back navigation

### Standard back (with browser history fallback)
```js
// In App.controller.js (base controller) — reuse in all controllers
onNavBack: function () {
    var oHistory = History.getInstance();
    var sPreviousHash = oHistory.getPreviousHash();
    if (sPreviousHash !== undefined) {
        window.history.go(-1);
    } else {
        this.getOwnerComponent().getRouter().navTo("list", {}, true);
    }
},
```

Required import:
```js
sap.ui.define([
    "sap/ui/core/routing/History"
], function (History) { ... });
```

### Show back button in Page
```xml
<Page showNavButton="true" navButtonPress=".onNavBack" title="{i18n>detailTitle}"/>
```

---

## 6. Nested routes & FCL (Flexible Column Layout)

For Flexible Column Layout (FCL), the router target needs `controlAggregation` mapped to columns:

```json
"targets": {
    "list": {
        "name": "List",
        "controlAggregation": "beginColumnPages",
        "controlId": "flexibleColumnLayout"
    },
    "detail": {
        "name": "Detail",
        "controlAggregation": "midColumnPages",
        "controlId": "flexibleColumnLayout"
    }
}
```

Update the FCL layout when navigating:
```js
this.getOwnerComponent().getModel("appState").setProperty("/layout",
    LayoutType.TwoColumnsMidExpanded
);
```

---

## 7. Deep links & URL parameters

### Current URL hash
```js
var sHash = this.getOwnerComponent().getRouter().oHashChanger.getHash();
```

### Navigate and store state for back
```js
// Store context before navigating (to restore on back)
this.getOwnerComponent().getModel("view").setProperty("/lastSelected", sId);
this.getOwnerComponent().getRouter().navTo("detail", { objectId: sId });
```

### Optional parameters (pattern with `?`)
```json
{ "name": "search", "pattern": "search/:query:", "target": ["search"] }
```

In controller:
```js
var sQuery = oEvent.getParameter("arguments")["query"] || "";
```
