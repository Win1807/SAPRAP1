sap.ui.define([
    "solicitudesui5/controller/App.controller"
], function (AppController) {
    "use strict";

    return AppController.extend("solicitudesui5.controller.{{Name}}", {

        onPress: function () {
            console.log("Item pressed");
        }
    });
});
