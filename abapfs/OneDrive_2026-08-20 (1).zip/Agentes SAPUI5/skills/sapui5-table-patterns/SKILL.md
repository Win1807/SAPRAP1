---
name: sapui5-table-patterns
description: >
  Plantillas y recomendaciones para listas y tablas SAPUI5 optimizadas:
  growing, virtualización, paginación, bindings eficientes y recomendaciones
  de backend para grandes volúmenes.
user-invocable: true
disable-model-invocation: false
metadata:
  display_name: SAPUI5 Table & List Patterns (Performance)
  version: "0.1.0"
  language: es
  platforms: [vscode, cli]
  categories: [sapui5, sap, ui5, table, list, performance]
---

# SAPUI5 Table & List Patterns (Performance) — instrucciones para el agente

## Propósito
Proveer plantillas, patrones y recomendaciones concretas para crear listas y tablas SAPUI5 eficientes y escalables, y para sugerir cambios en el backend/manifest cuando sea necesario.

---

## Reglas / Principios
1. **Evitar renderizar todos los registros de una vez**: preferir `growing`, `growingThreshold`, `delegation`, `virtualization` o paginación server-side según el control.
2. **Preferir binding por página o `$skip/$top` (OData)** cuando el dataset excede 500-1000 rows.
3. **No hardcodear filtros** en la vista; sugerir parámetros y ejemplo de filtro en controller.
4. **Agregar comentarios `// REVIEW`** si se requiere modificar servicios OData o cambiar `manifest.json`.
5. **Sugerir control apropiado**: `sap.m.List` / `sap.m.Table` para mobile-like, `sap.ui.table.Table` para pantallas de escritorio con columnas avanzadas.
6. **Indicar impacto en accesibilidad** cuando se usan técnicas de virtualización.

---

## Triggers y cuándo usar la skill
- Activar si el prompt contiene cualquiera de las frases en `triggers` o peticiones semánticamente relacionadas (ej. "optimizar tabla", "lista grande", "paginación UI5").
- Si el usuario menciona un número de registros alto (>1000), priorizar recomendaciones de paginación server-side y cambios dataSource.

---

## Plantillas completas (archivos)
Para plantillas completas usa los ficheros en `examples/`:

- `examples/sample-view.xml` — Vista XML con virtual scroll y binding delegado.
- `examples/sample-controller.js` — Controller con paginación OData.

Cuando el desarrollador pida "Usa la skill sapui5-table-patterns", reemplaza `{{Name}}` y `{{Entity}}` por el nombre indicado.
