---
applyTo: '**/*.controller.js'
---

## Documentación
**Descripción general**: Toda la documentación del código en los controladores se realizará mediante anotaciones JSDoc. Es necesario actualizar la documentación después de cada corrección o modificación en el código, actualizando la etiqueta `@memberof` con el valor de la etiqueta `@namespace` al inicio del archivo del controlador.

**Directrices**:
- Al inicio del archivo del controlador, se añadirá un comentario con las etiquetas `@file`, `@namespace` y `@author`. La etiqueta `@namespace` será el nombre del controlador y la etiqueta `@author` siempre será 'NTTData'.

Ejemplo:
  ```
  /**
    * @file Base controller for all controllers
    * @namespace App
    * @author NTTData
    */
  ```

- Cada una de las funciones del controlador se comentará mediante anotaciones. Los comentarios solo se generarán antes de la declaración de la función; no se generarán automáticamente en medio de la misma.
Siempre se añadirán las etiquetas `@description`, `@memberof`, `@method` y `@public`. Si corresponde, también se añadirán las etiquetas `@params` y `@return`.

Ejemplo de una función con parámetros de entrada y un valor de retorno:
  ```
  /**
    * @description Validates that there are selected records in the table
    * 
    * @memberof DetailDossier
    * @method _validLengthTable
    * @param {Object} oTable
    * @returns {Boolean}
    * @public
    */
  ```
