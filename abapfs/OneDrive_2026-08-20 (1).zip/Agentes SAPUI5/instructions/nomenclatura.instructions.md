---
applyTo: '**/*.js,**/*.ts'
---

# Convenciones de nomenclatura de SAPUI5
Este documento describe las convenciones de nomenclatura que se deben seguir al desarrollar aplicaciones con SAPUI5. El cumplimiento de estas convenciones ayuda a mantener la coherencia y la claridad en el código fuente, lo que facilita la colaboración entre desarrolladores y la comprensión del trabajo de los demás.

## 1. Nombres de clase
**Formato**: `Namespace.ComponentName`

**Descripción**: Los nombres de clase deben estructurarse para reflejar el espacio de nombres de la aplicación y el componente específico. Esto ayuda a organizar el código y a evitar conflictos de nombres.

Ejemplo:
- `MyApp.controller.Main` para una clase de controlador.
- `MyApp.model.UserModel` para una clase de modelo.

## 2. Nombres de controlador
**Formato**: `Namespace.ComponentNameController`

**Descripción**: Los controladores siempre deben terminar con el sufijo `Controller` para indicar claramente su función en la arquitectura MVC.

Ejemplo:
- `MyApp.controller.MainController` para el controlador principal.
- `MyApp.controller.DetailController` para un controlador detallado.

## 3. Nombres de las vistas
**Formato**: `ComponentName.view.xml`

**Descripción**: Los archivos de vista deben nombrarse de forma que reflejen su propósito, seguidos del sufijo `.view.xml`. Esto indica que el archivo es una vista XML.

Ejemplo:
- `MainView.view.xml` para la vista principal.
- `DetailView.view.xml` para una vista detallada.

## 4. Nombres de los modelos
**Formato**: `oDataModel`, `jsonModel`, etc.

**Descripción**: Los nombres de los modelos deben indicar el tipo de datos que representan. Esto facilita la comprensión de la estructura de datos de un vistazo.

Ejemplo:
- `oDataModel` para un modelo OData.
- `jsonModel` para un modelo JSON.
- `userModel` para un modelo que gestione específicamente los datos de usuario.

## 5. Nombres de recursos
- **Formato**: `i18n.properties`

**Descripción**: Los archivos de recursos, como los de internacionalización, deben nombrarse de forma que indiquen su función. El prefijo `i18n` se usa habitualmente para la internacionalización.

Ejemplo:
- `i18n.properties` para los recursos en el idioma predeterminado.
- `i18n_en.properties` para los recursos en inglés.
- `i18n_de.properties` para los recursos en alemán.

## 6. Nombres de funciones
**Formato**: `verbNoun`

**Descripción**: Los nombres de las funciones deben ser descriptivos y seguir el formato `verboSustantivo` para indicar claramente su acción y el objeto sobre el que actúan. Dado que se consideran funciones privadas (se ejecutan desde otras funciones), deben comenzar con un guion bajo.

Ejemplo:
- Función privada `_getUserData()` para recuperar datos de usuario.
- Función privada `_setUserData(data)` para establecer datos de usuario.

## 7. Nombres de eventos
**Formato**: `on<EventName> + actionVerb`

**Descripción**: Las funciones de controlador de eventos deben comenzar con el prefijo `on` seguido del nombre del evento. Esta convención deja claro que la función es un controlador de eventos.

Ejemplo:
- `onInit()` para eventos de inicialización.
- `onPressSave()` para guardar los datos de un formulario.
- `onChangeData()` para modificar los datos de un formulario.

## 8. Nombres de propiedades
**Formato**: `camelCase`

**Descripción**: Las propiedades deben nombrarse usando camelCase para mantener la coherencia con las convenciones de JavaScript.

Ejemplo:
- `userName` para la propiedad del nombre de un usuario.
- `isActive` para una propiedad booleana que indica el estado activo.

## 9. Nombres de variables
**Formato**: `camelCase`

**Descripción**: Los nombres de las variables también deben usar camelCase. Deben ser lo suficientemente descriptivos para indicar su propósito y se debe evitar el uso de nombres de una sola letra, excepto para los contadores de bucle.
Es importante evitar en lo posible el uso de variables globales, así como de modelos globales que afectan a todas las vistas.

La primera letra del nombre de la variable debe corresponder al tipo de dato de dicha variable:
- Si el elemento de datos es `Boolean`, la variable comenzará con "b".
- Si el elemento de datos es `Integer`, la variable comenzará con "i".
- Si el elemento de datos es `Float`, la variable comenzará con "f".
- Si el elemento de datos es `String`, la variable comenzará con "s".
- Si el elemento de datos es `Object`, la variable comenzará con "o".
- Si el elemento de datos es un `Array`, la variable comenzará con "a".
- Si el elemento de datos es una `Date`, la variable comenzará con "d".

Ejemplo:
- `aUserList` para una lista de usuarios.
- `fTotalAmount` para una variable que representa un importe total.
- `iCounter` para un contador de bucle.

## 10. Constantes
**Formato**: `UPPER_SNAKE_CASE`

**Descripción**: Las constantes deben nombrarse con letras mayúsculas y palabras separadas por guiones bajos. Esta convención ayuda a distinguir las constantes de las variables normales.
Las constantes deben declararse en el archivo constants.js dentro de la carpeta "utils" en la aplicación web.

Ejemplo:
- `MAX_USERS` para el número máximo de usuarios permitidos.
- `API_URL` para la URL base de una API.
